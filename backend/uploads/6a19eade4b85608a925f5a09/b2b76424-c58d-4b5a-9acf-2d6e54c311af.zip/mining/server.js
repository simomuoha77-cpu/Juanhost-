require('dotenv').config();
const express    = require('express');
const mongoose   = require('mongoose');
const bcrypt     = require('bcryptjs');
const jwt        = require('jsonwebtoken');
const helmet     = require('helmet');
const cors       = require('cors');
const rateLimit  = require('express-rate-limit');
const morgan     = require('morgan');
const axios      = require('axios');
const path       = require('path');
const crypto     = require('crypto');
const fs         = require('fs');

const app = express();

// ── TRUST PROXY — required on Render/Heroku/any reverse-proxy host ──
// Without this, express-rate-limit throws ERR_ERL_UNEXPECTED_X_FORWARDED_FOR
// because it sees X-Forwarded-For but doesn't know the proxy is trusted.
app.set('trust proxy', 1);

// ═══════════════════════════════════════════════════════════
//  DATABASE
// ═══════════════════════════════════════════════════════════
// Validate critical env vars
if (!process.env.JWT_SECRET) {
  console.error('❌ FATAL: JWT_SECRET is not set in environment variables');
  process.exit(1);
}
if (!process.env.MONGO_URI) {
  console.error('❌ FATAL: MONGO_URI is not set in environment variables');
  process.exit(1);
}
console.log('✅ Environment check passed');

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser:true, useUnifiedTopology:true })
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => { console.error('❌ MongoDB:', err); process.exit(1); });

// ── SCHEMAS ─────────────────────────────────────────────────
const UserSchema = new mongoose.Schema({
  name:           { type:String, required:true, trim:true, maxlength:80 },
  email:          { type:String, required:true, unique:true, lowercase:true, trim:true },
  password:       { type:String, required:true, minlength:6, select:false },
  phone:          { type:String, trim:true },
  role:           { type:String, enum:['user','admin'], default:'user' },
  balance:        { type:Number, default:0 },
  totalDeposits:  { type:Number, default:0 },
  totalEarned:    { type:Number, default:0 },
  totalWithdrawn: { type:Number, default:0 },
  refBonus:       { type:Number, default:0 },
  tier:           { type:String, enum:['starter','bronze','silver','gold','platinum','diamond','vip','elite'], default:'starter' },
  lastEarningDate:{ type:String, default:null },
  lastCheckin:    { type:String, default:null },
  checkinStreak:  { type:Number, default:0 },
  daysActive:     { type:Number, default:0 },
  referralCode:   { type:String, unique:true, sparse:true },
  referredBy:     { type:String, default:null },
  referrals:      [{ type:String }],
  isActive:       { type:Boolean, default:true },
  kycStatus:      { type:String, enum:['pending','verified','rejected'], default:'pending' },
  kycDoc:         { type:String, default:null },
  welcomeBonusGiven:{ type:Boolean, default:false },
  twoFactorEnabled: { type:Boolean, default:false },
  loginHistory:   [{ ip:String, time:Date, device:String }],
  firstDepositBonus:{ type:Number, default:0 },
  tokenVersion:     { type:Number, default:0 }, // increment to invalidate all tokens
  passwordChangedAt:{ type:Date, default:null },
  lastActivityAt:   { type:Date, default:null },
}, { timestamps:true });
UserSchema.pre('save', async function(next) {
  if (this.isModified('password')) this.password = await bcrypt.hash(this.password, 12);
  if (!this.referralCode) this.referralCode = 'IVG-' + Math.random().toString(36).substr(2,6).toUpperCase();
  next();
});
const User = mongoose.model('User', UserSchema);

const TxSchema = new mongoose.Schema({
  user:     { type:mongoose.Schema.Types.ObjectId, ref:'User', required:true },
  email:    String, type:{ type:String, enum:['deposit','withdrawal','earning','refbonus','refund'], required:true },
  amount:   { type:Number, required:true },
  label:    String, status:{ type:String, enum:['pending','completed','rejected','failed'], default:'completed' },
  method:   String, mpesaRef:String, checkoutRequestId:String, phone:String, tier:String,
}, { timestamps:true });
const Transaction = mongoose.model('Transaction', TxSchema);
// ── PERFORMANCE INDEXES ──
TxSchema.index({ user:1, createdAt:-1 });
TxSchema.index({ checkoutRequestId:1 });
TxSchema.index({ status:1, type:1 });

const SettingsSchema = new mongoose.Schema({ key:{ type:String, unique:true }, value:mongoose.Schema.Types.Mixed });
const Settings = mongoose.model('Settings', SettingsSchema);

const AnnSchema = new mongoose.Schema({ title:String, body:String, active:{ type:Boolean, default:true } }, { timestamps:true });
const Announcement = mongoose.model('Announcement', AnnSchema);

const OTPSchema = new mongoose.Schema({
  email:{ type:String, required:true }, code:{ type:String, required:true },
  expiresAt:{ type:Date, required:true },
});
OTPSchema.index({ expiresAt:1 }, { expireAfterSeconds:0 });
const OTP = mongoose.model('OTP', OTPSchema);

const MessageSchema = new mongoose.Schema({
  to:{ type:mongoose.Schema.Types.ObjectId, ref:'User', default:null },
  toEmail:String, subject:String, body:String,
  isRead:{ type:Boolean, default:false }, isBroadcast:{ type:Boolean, default:false },
}, { timestamps:true });
const Message = mongoose.model('Message', MessageSchema);

const ActivitySchema = new mongoose.Schema({
  user:{ type:mongoose.Schema.Types.ObjectId, ref:'User' },
  email:String, action:String, details:String, ip:String,
}, { timestamps:true });
const Activity = mongoose.model('Activity', ActivitySchema);

const SocialSchema = new mongoose.Schema({
  name:String, url:String, icon:String, active:{ type:Boolean, default:true }
}, { timestamps:true });
const Social = mongoose.model('Social', SocialSchema);


// KYC Documents
const KYCSchema = new mongoose.Schema({
  user:    { type:mongoose.Schema.Types.ObjectId, ref:'User', required:true },
  docType: String,
  docUrl:  String,
  status:  { type:String, enum:['pending','verified','rejected'], default:'pending' },
  note:    String,
}, { timestamps:true });
const KYC = mongoose.model('KYC', KYCSchema);


// Refresh tokens (for token rotation)
const RefreshTokenSchema = new mongoose.Schema({
  user:      { type:mongoose.Schema.Types.ObjectId, ref:'User', required:true },
  token:     { type:String, required:true, unique:true },
  expiresAt: { type:Date, required:true },
  used:      { type:Boolean, default:false },
});
RefreshTokenSchema.index({ expiresAt:1 }, { expireAfterSeconds:0 });
const RefreshToken = mongoose.model('RefreshToken', RefreshTokenSchema);

// Admin action log
const AdminLogSchema = new mongoose.Schema({
  admin:    { type:mongoose.Schema.Types.ObjectId, ref:'User' },
  adminEmail: String,
  action:   String,
  target:   String,
  details:  String,
  ip:       String,
}, { timestamps:true });
const AdminLog = mongoose.model('AdminLog', AdminLogSchema);

// Login History
const LoginSchema = new mongoose.Schema({
  user:    { type:mongoose.Schema.Types.ObjectId, ref:'User' },
  email:   String,
  ip:      String,
  device:  String,
  status:  String,
}, { timestamps:true });
const LoginLog = mongoose.model('LoginLog', LoginSchema);

// Platform Stats (public)
const StatsCache = { data:null, updatedAt:null };


// APK Download
const APKSchema = new mongoose.Schema({
  version:   { type:String, required:true },
  filename:  { type:String, required:true },
  url:       { type:String, required:true },
  size:      { type:String, default:'Unknown' },
  changelog: { type:String, default:'' },
  active:    { type:Boolean, default:true },
  downloads: { type:Number, default:0 },
}, { timestamps:true });
const APK = mongoose.model('APK', APKSchema);


// Social Proof - admin editable fake stats
const SocialProofSchema = new mongoose.Schema({
  key:   { type:String, unique:true },
  value: mongoose.Schema.Types.Mixed,
}, { timestamps:true });
const SocialProof = mongoose.model('SocialProof', SocialProofSchema);

// ═══════════════════════════════════════════════════════════
//  MINING MACHINE SCHEMAS
// ═══════════════════════════════════════════════════════════

// Mining Machine (admin-defined products)
const MiningMachineSchema = new mongoose.Schema({
  name:          { type:String, required:true, trim:true },
  description:   { type:String, default:'' },
  imageUrl:      { type:String, default:'' },     // URL or base64
  price:         { type:Number, required:true },   // KSH purchase price
  dailyEarning:  { type:Number, required:true },   // KSH earned per 24-hr mine session
  durationHours: { type:Number, default:24 },      // hours before next mine allowed
  totalSlots:    { type:Number, default:100 },      // how many can be purchased
  soldCount:     { type:Number, default:0 },
  isActive:      { type:Boolean, default:true },
  category:      { type:String, default:'ASIC' },
  hashrate:      { type:String, default:'' },      // display only e.g. "14 TH/s"
  power:         { type:String, default:'' },      // display only e.g. "1350W"
}, { timestamps:true });
const MiningMachine = mongoose.model('MiningMachine', MiningMachineSchema);
MiningMachineSchema.index({ isActive:1, price:1 });

// User-owned machine (purchase record)
const UserMachineSchema = new mongoose.Schema({
  user:          { type:mongoose.Schema.Types.ObjectId, ref:'User', required:true },
  machine:       { type:mongoose.Schema.Types.ObjectId, ref:'MiningMachine', required:true },
  purchasedAt:   { type:Date, default:Date.now },
  lastMinedAt:   { type:Date, default:null },       // when user last clicked "Mine"
  totalEarned:   { type:Number, default:0 },
  isActive:      { type:Boolean, default:true },
}, { timestamps:true });
const UserMachine = mongoose.model('UserMachine', UserMachineSchema);
UserMachineSchema.index({ user:1, isActive:1 });
UserMachineSchema.index({ user:1, purchasedAt:-1 });

// ═══════════════════════════════════════════════════════════
//  HIGH MINING MACHINE SCHEMAS
// ═══════════════════════════════════════════════════════════
const HighMachineSchema = new mongoose.Schema({
  name:         { type:String, required:true },
  description:  { type:String, default:'' },
  imageUrl:     { type:String, default:'' },
  price:        { type:Number, required:true },
  totalEarning: { type:Number, required:true },  // total payout when timer ends
  durationHours:{ type:Number, required:true },  // countdown hours
  startTime:    { type:Date, default:null },      // set when admin opens
  endTime:      { type:Date, default:null },      // startTime + durationHours
  isOpen:       { type:Boolean, default:false },  // admin controls purchasing
  isActive:     { type:Boolean, default:true },
  totalSlots:   { type:Number, default:100 },
  soldCount:    { type:Number, default:0 },
  createdAt:    { type:Date, default:Date.now },
});
const HighMachine = mongoose.model('HighMachine', HighMachineSchema);

const UserHighMachineSchema = new mongoose.Schema({
  user:        { type:mongoose.Schema.Types.ObjectId, ref:'User', required:true },
  machine:     { type:mongoose.Schema.Types.ObjectId, ref:'HighMachine', required:true },
  purchasedAt: { type:Date, default:Date.now },
  claimed:     { type:Boolean, default:false },
  claimedAt:   { type:Date, default:null },
  isActive:    { type:Boolean, default:true },
});
const UserHighMachine = mongoose.model('UserHighMachine', UserHighMachineSchema);


// ═══════════════════════════════════════════════════════════
//  MIDDLEWARE
// ═══════════════════════════════════════════════════════════
// ── HELMET — security headers ──
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));
app.use(helmet.noSniff());
app.use(helmet.hidePoweredBy());
app.use(helmet.xssFilter());
app.use(helmet.frameguard({ action: 'deny' }));

// ── BLOCK SOURCE CODE VIEWING ──
app.use((req, res, next) => {
  // Block requests trying to read raw HTML source
  const ua = (req.headers['user-agent'] || '').toLowerCase();
  const accept = (req.headers['accept'] || '').toLowerCase();
  const isCurl = ua.includes('curl') || ua.includes('wget') || ua.includes('python') || ua.includes('httpie') || ua.includes('go-http');
  const isApiTool = ua.includes('postman') || ua.includes('insomnia') || ua.includes('burpsuite') || ua.includes('zaproxy');
  const wantsHtml = req.path === '/' || req.path.endsWith('.html');
  // If it looks like a scraping tool hitting HTML pages, return empty
  if (wantsHtml && (isCurl || isApiTool) && !accept.includes('text/html')) {
    return res.status(200).send('');
  }
  // Block view-source attempts via missing browser fingerprint
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  next();
});

// ── BODY PARSING ──
app.use(express.json({ limit: '5mb' }));
app.use(morgan('combined'));

// ── CORS — strict origin ──
const allowedOrigins = [
  process.env.FRONTEND_URL,
  'https://impactvest.co.ke',
  'https://www.impactvest.co.ke',
  'https://impactvest-global-3bnr.onrender.com',
  'https://impactvest-global-ptic.onrender.com',
  'http://localhost:5000',
  'http://localhost:3000',
].filter(Boolean);
app.use(cors({
  origin: (origin, cb) => {
    // Allow all origins in development or if no origin (mobile apps, curl)
    if (!origin) return cb(null, true);
    if (allowedOrigins.includes(origin)) return cb(null, true);
    if (process.env.NODE_ENV !== 'production') return cb(null, true);
    // Allow same-origin requests (served from same server)
    cb(null, true); // Allow all for now - restrict after testing
  },
  methods: ['GET','POST','PUT','PATCH','DELETE'],
  allowedHeaders: ['Content-Type','Authorization'],
  credentials: true,
}));

// ── RATE LIMITERS ──
// Global
app.use('/api/', rateLimit({ windowMs:15*60*1000, max:300, message:{ error:'Too many requests. Slow down.' }, standardHeaders:true, legacyHeaders:false }));
// Auth endpoints — strict
const authLimiter = rateLimit({ windowMs:15*60*1000, max:10, message:{ error:'Too many login attempts. Try again in 15 minutes.' }, skipSuccessfulRequests:false });
// Deposit endpoint
const depositLimiter = rateLimit({ windowMs:5*60*1000, max:5, message:{ error:'Too many deposit requests.' } });
// Checkin endpoint
const checkinLimiter = rateLimit({ windowMs:24*60*60*1000, max:3, message:{ error:'Check-in limit reached.' } });
// Withdrawal endpoint
const mineLimiter = rateLimit({ windowMs:60*1000, max:5, message:{ error:'Too many mine requests. Slow down.' } });
const withdrawLimiter = rateLimit({ windowMs:60*60*1000, max:5, message:{ error:'Too many withdrawal requests.' } });

// ── BLOCK SUSPICIOUS PATHS ──
const BANNED = ['.php','.env','wp-admin','wp-login','xmlrpc','eval(','.git','etc/passwd','cmd=','exec('];
app.use((req, res, next) => {
  const p = req.path.toLowerCase();
  const q = JSON.stringify(req.query).toLowerCase();
  if (BANNED.some(b => p.includes(b) || q.includes(b)))
    return res.status(403).json({ error:'Forbidden' });
  next();
});


// ── SECURITY: Mass Assignment Protection ──────────────────
// Strip dangerous fields from ALL user-facing request bodies
const FORBIDDEN_FIELDS = ['role','balance','totalDeposits','totalWithdrawn','totalEarned',
  'isActive','isVerified','referralCode','referrals','refBonus','_id','__v',
  'loginHistory','createdAt','updatedAt'];

// Auth routes that legitimately use email/password
const AUTH_ROUTES = ['/auth/login','/auth/register','/auth/send-otp','/auth/verify-otp','/auth/forgot-password','/auth/reset-password'];

app.use('/api/', (req, res, next) => {
  if (req.body && typeof req.body === 'object') {
    const isAuthRoute = AUTH_ROUTES.some(r => req.path.includes(r));
    const isAdminRoute = req.path.startsWith('/admin/');
    if (!isAuthRoute && !isAdminRoute) {
      const stripped = [];
      FORBIDDEN_FIELDS.forEach(field => {
        if (req.body[field] !== undefined) {
          stripped.push(field);
          delete req.body[field];
        }
      });
      if (stripped.length > 0) {
        console.warn(`⚠️  Mass assignment blocked: [${stripped.join(', ')}] from IP ${(req.headers['x-forwarded-for']||req.socket.remoteAddress||'').split(',')[0].trim()}`);
      }
    }
  }
  next();
});


// ── SECURITY: NoSQL Injection Prevention (key-level only) ──
// Only strip $ operator keys — never touch string values (breaks email/password)
app.use((req, res, next) => {
  function stripDollarKeys(obj, depth=0) {
    if (depth > 5 || !obj || typeof obj !== 'object' || Array.isArray(obj)) return obj;
    const clean = {};
    for (const key of Object.keys(obj)) {
      if (key.startsWith('$')) {
        console.warn(`🚨 NoSQL operator key blocked: "${key}" from ${(req.headers['x-forwarded-for']||'').split(',')[0]}`);
        continue;
      }
      clean[key] = stripDollarKeys(obj[key], depth+1);
    }
    return clean;
  }
  if (req.body && typeof req.body === 'object') req.body = stripDollarKeys(req.body);
  next();
});


// ── SECURITY: XSS Prevention — escape HTML in stored text ──
function escapeHtml(str) {
  if (typeof str !== 'string') return str;
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
    .replace(/`/g, '&#x60;')
    .trim();
}
function sanitizeUserText(obj, fields) {
  const clean = { ...obj };
  fields.forEach(f => { if (clean[f]) clean[f] = escapeHtml(clean[f]); });
  return clean;
}

// ── BLOCK NON-JSON API REQUESTS ──
app.use('/api/', (req, res, next) => {
  if (['POST','PUT','PATCH'].includes(req.method) && !req.is('application/json'))
    return res.status(415).json({ error:'Content-Type must be application/json' });
  next();
});

// ── ADMIN ACTION LOGGER ──
async function logAdminAction(req, action, target, details) {
  try {
    await AdminLog.create({
      admin: req.user?._id,
      adminEmail: req.user?.email,
      action, target, details,
      ip: req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown'
    });
  } catch(e) {}
}


// ═══════════════════════════════════════════════════════════
//  EMAIL SERVICE — Brevo (Sendinblue) HTTP API
//
//  Render free tier BLOCKS all SMTP ports (25, 465, 587).
//  Brevo sends over HTTPS (port 443) — never blocked.
//  Free plan: 300 emails/day — perfect for OTPs.
//
//  SETUP (5 min, free):
//  1. https://app.brevo.com → Sign up free (no card needed)
//  2. Top-right menu → SMTP & API → API Keys → Generate new key
//  3. Senders & IPs → Senders → Add a sender → verify your email
//  4. Add to Render env vars:
//       BREVO_API_KEY  = xkeysib-xxxxxxxx (your API key)
//       EMAIL_USER     = youremail@gmail.com (your verified sender)
// ═══════════════════════════════════════════════════════════

if (!process.env.BREVO_API_KEY) {
  console.warn('⚠️  EMAIL: BREVO_API_KEY not set — emails will NOT send');
  console.warn('⚠️  Sign up free at https://app.brevo.com → API Keys → add BREVO_API_KEY in Render');
} else {
  console.log(`✅ EMAIL: Brevo ready | sender=${process.env.EMAIL_USER || 'not set'}`);
}

async function sendEmail(to, subject, html) {
  if (!process.env.BREVO_API_KEY) {
    console.log(`📧 [SKIPPED - no BREVO_API_KEY] To: ${to} | ${subject}`);
    return;
  }
  try {
    const resp = await axios.post('https://api.brevo.com/v3/smtp/email', {
      sender:      { name: 'ImpactVest Global', email: process.env.EMAIL_USER || 'noreply@impactvest.co.ke' },
      to:          [{ email: to }],
      subject,
      htmlContent: html,
      textContent: html.replace(/<[^>]+>/g, '').replace(/\s{2,}/g, ' ').trim(),
    }, {
      headers: {
        'api-key':      process.env.BREVO_API_KEY,
        'Content-Type': 'application/json',
        'Accept':       'application/json',
      },
      timeout: 15000,
    });
    console.log(`✅ EMAIL sent → ${to} | id: ${resp.data.messageId || 'ok'}`);
  } catch (err) {
    const detail = err.response?.data?.message || err.message;
    console.error(`❌ EMAIL FAILED → ${to} | ${detail}`);
    throw new Error(detail);
  }
}


function buildEmailTemplate(name, subject, body) {
  return `
    <div style="font-family:Arial,sans-serif;max-width:580px;margin:0 auto;background:#0d0f14;color:#e4eaf5;border-radius:16px;overflow:hidden">
      <!-- Header -->
      <div style="background:linear-gradient(135deg,#1a1608,#141b28);padding:28px 32px;border-bottom:1px solid #2a3548;text-align:center">
        <div style="display:inline-flex;align-items:center;gap:10px">
          <div style="width:36px;height:36px;background:linear-gradient(135deg,#c9a84c,#e8c96a);transform:rotate(45deg);border-radius:6px"></div>
          <span style="font-size:22px;font-weight:700;color:#c9a84c;letter-spacing:.5px">ImpactVest Global</span>
        </div>
        <p style="color:#6b7e99;font-size:12px;margin-top:6px;letter-spacing:2px;text-transform:uppercase">Smart Investment Platform</p>
      </div>
      <!-- Body -->
      <div style="padding:32px">
        <p style="color:#6b7e99;font-size:14px;margin-bottom:8px">Hello, <strong style="color:#e4eaf5">${name}</strong> 👋</p>
        <h2 style="font-size:20px;font-weight:700;margin-bottom:16px;color:#e4eaf5">${subject}</h2>
        <div style="background:#1e2638;border-left:3px solid #c9a84c;border-radius:0 10px 10px 0;padding:20px 24px;margin-bottom:24px;font-size:14px;line-height:1.8;color:#dce8f5">
          ${body.replace(/\n/g,'<br>')}
        </div>
        <a href="${process.env.FRONTEND_URL||'https://impactvest-global.onrender.com'}" 
           style="display:inline-block;background:linear-gradient(135deg,#c9a84c,#e8c96a);color:#000;font-weight:700;padding:13px 28px;border-radius:10px;text-decoration:none;font-size:14px">
          Login to Your Account →
        </a>
      </div>
      <!-- Footer -->
      <div style="background:#0c1018;padding:20px 32px;border-top:1px solid #2a3548;text-align:center">
        <p style="color:#6b7e99;font-size:11px;margin:0">© 2026 ImpactVest Global · <a href="mailto:${process.env.EMAIL_USER}" style="color:#c9a84c;text-decoration:none">noreply@impactvest.co.ke</a></p>
        <p style="color:#4a6080;font-size:10px;margin-top:6px">You are receiving this because you have an account with ImpactVest Global.</p>
      </div>
    </div>
  `;
}


// ═══════════════════════════════════════════════════════════
//  AUTH MIDDLEWARE
// ═══════════════════════════════════════════════════════════
// Helper: generate tokens
function generateAccessToken(user) {
  return jwt.sign(
    { id: user._id, v: user.tokenVersion||0 },
    process.env.JWT_SECRET,
    { expiresIn: '30d' }
  );
}
async function generateRefreshToken(userId) {
  const token = require('crypto').randomBytes(40).toString('hex');
  await RefreshToken.create({ user:userId, token, expiresAt: new Date(Date.now() + 7*24*60*60*1000) });
  return token;
}

const protect = async (req, res, next) => {
  try {
    const auth = req.headers.authorization;
    if (!auth||!auth.startsWith('Bearer ')) return res.status(401).json({ error:'Not authenticated' });
    const token = auth.split(' ')[1];
    let decoded;
    try { decoded = jwt.verify(token, process.env.JWT_SECRET); }
    catch(e) {
      if (e.name === 'TokenExpiredError') return res.status(401).json({ error:'Session expired. Please login again.', expired:true });
      return res.status(401).json({ error:'Invalid token' });
    }
    const user = await User.findById(decoded.id).select('-password');
    if (!user) return res.status(401).json({ error:'Account not found' });
    if (!user.isActive) return res.status(403).json({ error:'Account suspended. Contact support.' });
    // Check token version — only invalidate if user explicitly has tokenVersion set
    if (decoded.v !== undefined && user.tokenVersion !== undefined && user.tokenVersion !== null && decoded.v !== user.tokenVersion)
      return res.status(401).json({ error:'Session invalidated. Please login again.', expired:true });
    req.user = user;
    // Update last activity
    User.findByIdAndUpdate(user._id, { lastActivityAt: new Date() }).catch(()=>{});
    next();
  } catch(e) { res.status(401).json({ error:'Invalid or expired token' }); }
};

const adminOnly = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') return res.status(403).json({ error:'Admin access required' });
  next();
};

// Strong input validator
function validateAmount(val, min=1, max=10000000) {
  const n = parseFloat(val);
  if (isNaN(n) || n < min || n > max) return false;
  return parseFloat(n.toFixed(2));
}

// ═══════════════════════════════════════════════════════════
//  INVESTMENT TIERS
// ═══════════════════════════════════════════════════════════
const TIERS = {
  starter:  { rate:0.03,  min:500,   max:999,    label:'Starter',  icon:'🚗' },
  bronze:   { rate:0.04,  min:1000,  max:1999,   label:'Bronze',   icon:'🏎️' },
  silver:   { rate:0.05,  min:2000,  max:2999,   label:'Silver',   icon:'🚙' },
  gold:     { rate:0.06,  min:3000,  max:4999,   label:'Gold',     icon:'🏎️' },
  platinum: { rate:0.07,  min:5000,  max:9999,   label:'Platinum', icon:'✈️' },
  diamond:  { rate:0.09,  min:10000, max:24999,  label:'Diamond',  icon:'🛥️' },
  vip:      { rate:0.11,  min:25000, max:49999,  label:'VIP',      icon:'🏰' },
  elite:    { rate:0.15,  min:50000, max:Infinity,label:'Elite',   icon:'🚀' },
};
function getTierForAmount(amount) {
  for (const [key, t] of Object.entries(TIERS)) if (amount >= t.min && amount <= t.max) return key;
  return 'starter';
}

// ═══════════════════════════════════════════════════════════
//  MPESA
// ═══════════════════════════════════════════════════════════

// ⚠️  NOTE: MPESA_BASE is resolved at call-time (not module load)
//    so changing MPESA_ENV in Render env vars takes effect without
//    needing to redeploy.
function getMpesaBase() {
  return process.env.MPESA_ENV === 'production'
    ? 'https://api.safaricom.co.ke'
    : 'https://sandbox.safaricom.co.ke';
}

// Startup warning — missing MPESA vars won't crash the server but will
// cause every STK push to fail, so log them clearly.
const _mpesaVars = ['MPESA_CONSUMER_KEY','MPESA_CONSUMER_SECRET','MPESA_SHORTCODE','MPESA_PASSKEY','MPESA_CALLBACK_URL','MPESA_CALLBACK_SECRET','MPESA_ENV'];
const _missingMpesa = _mpesaVars.filter(v => !process.env[v]);
if (_missingMpesa.length) {
  console.warn(`⚠️  MPESA: missing env vars → ${_missingMpesa.join(', ')}`);
  console.warn(`⚠️  MPESA_ENV is currently: "${process.env.MPESA_ENV || 'NOT SET'}" (must be "production" for live)`);
} else {
  console.log(`✅ MPESA: all env vars present | ENV=${process.env.MPESA_ENV} | BASE=${getMpesaBase()}`);
}

async function getMpesaToken() {
  const base = getMpesaBase();
  const auth = Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString('base64');
  const r = await axios.get(`${base}/oauth/v1/generate?grant_type=client_credentials`, { headers:{ Authorization:`Basic ${auth}` } });
  return r.data.access_token;
}
async function stkPush(phone, amount, ref, desc) {
  const base = getMpesaBase();
  const token = await getMpesaToken();
  const ts = new Date().toISOString().replace(/[^0-9]/g,'').slice(0,14);
  const pass = Buffer.from(`${process.env.MPESA_SHORTCODE}${process.env.MPESA_PASSKEY}${ts}`).toString('base64');
  let tel = phone.replace(/\s/g,'').replace(/^0/,'254').replace(/^\+/,'');
  console.log(`[STK] ENV=${process.env.MPESA_ENV} | BASE=${base} | SHORT=${process.env.MPESA_SHORTCODE} | TEL=${tel} | AMT=${amount}`);
  const r = await axios.post(`${base}/mpesa/stkpush/v1/processrequest`, {
    BusinessShortCode:process.env.MPESA_SHORTCODE, Password:pass, Timestamp:ts,
    TransactionType:'CustomerPayBillOnline', Amount:Math.ceil(amount),
    PartyA:tel, PartyB:process.env.MPESA_SHORTCODE, PhoneNumber:tel,
    CallBackURL:(process.env.MPESA_CALLBACK_URL||'').replace('/callback','/callback/'+( process.env.MPESA_CALLBACK_SECRET||'changeme')), AccountReference:ref, TransactionDesc:desc
  }, { headers:{ Authorization:`Bearer ${token}` } });
  return r.data;
}

// ═══════════════════════════════════════════════════════════
//  DAILY EARNINGS ENGINE
// ═══════════════════════════════════════════════════════════
async function applyDailyEarnings(userId) {
  const user = await User.findById(userId);
  if (!user || user.totalDeposits === 0) return;
  const today = new Date().toDateString();
  if (user.lastEarningDate === today) return;
  const rate = (TIERS[user.tier] || TIERS.starter).rate;
  const earned = parseFloat((user.totalDeposits * rate).toFixed(2));
  user.balance = parseFloat((user.balance + earned).toFixed(2));
  user.totalEarned = parseFloat(((user.totalEarned||0) + earned).toFixed(2));
  user.lastEarningDate = today;
  user.daysActive = (user.daysActive||0) + 1;
  await user.save();
  await Transaction.create({ user:user._id, email:user.email, type:'earning', amount:earned, label:`Daily Earnings — ${TIERS[user.tier]?.label} (${(rate*100).toFixed(0)}%)`, status:'completed', tier:user.tier });
}

// ═══════════════════════════════════════════════════════════
//  AUTH ROUTES
// ═══════════════════════════════════════════════════════════
app.post('/api/auth/send-otp', authLimiter, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error:'Email required' });
    // Basic email format check
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      return res.status(400).json({ error:'Invalid email address' });
    if (await User.findOne({ email })) return res.status(400).json({ error:'Email already registered' });

    // Generate 6-digit code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    await OTP.deleteMany({ email });
    await OTP.create({ email, code, expiresAt: new Date(Date.now() + 10*60*1000) });

    // Always log OTP to Render logs — useful backup if email fails
    console.log(`🔑 OTP generated | email=${email} | code=${code} | expires=10min`);

    // Build a clean OTP email
    const otpHtml = `
      <div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto;background:#0d0f14;color:#e4eaf5;border-radius:16px;overflow:hidden">
        <!-- Header -->
        <div style="background:linear-gradient(135deg,#1a1608,#141b28);padding:28px 32px;border-bottom:1px solid #2a3548;text-align:center">
          <div style="font-size:22px;font-weight:700;color:#c9a84c;letter-spacing:.5px">ImpactVest Global</div>
          <p style="color:#6b7e99;font-size:12px;margin-top:6px;letter-spacing:2px;text-transform:uppercase">Email Verification</p>
        </div>
        <!-- Body -->
        <div style="padding:32px">
          <p style="color:#6b7e99;font-size:15px;margin-bottom:20px">
            You requested to create an ImpactVest Global account. Use the code below to verify your email address.
          </p>
          <!-- OTP Box -->
          <div style="background:#1e2638;border:2px solid #c9a84c;border-radius:14px;padding:28px;text-align:center;margin-bottom:24px">
            <p style="color:#6b7e99;font-size:12px;margin:0 0 12px;text-transform:uppercase;letter-spacing:2px">Your Verification Code</p>
            <div style="font-size:46px;font-weight:700;letter-spacing:14px;color:#c9a84c;font-family:Courier New,monospace;margin-bottom:12px">${code}</div>
            <p style="color:#6b7e99;font-size:12px;margin:0">⏱ Expires in <strong style="color:#e4eaf5">10 minutes</strong></p>
          </div>
          <p style="color:#4a6080;font-size:12px;line-height:1.7">
            If you did not request this code, you can safely ignore this email.<br>
            Never share this code with anyone — ImpactVest will never ask for it.
          </p>
        </div>
        <!-- Footer -->
        <div style="background:#0c1018;padding:16px 32px;border-top:1px solid #2a3548;text-align:center">
          <p style="color:#4a6080;font-size:11px;margin:0">© 2026 ImpactVest Global · noreply@impactvest.co.ke</p>
        </div>
      </div>`;

    // Send email — await it so we know if it worked before responding
    let emailSent = false;
    let emailError = null;
    try {
      await sendEmail(email, `ImpactVest Verification Code: ${code}`, otpHtml);
      emailSent = true;
      console.log(`✅ OTP email delivered → ${email}`);
    } catch (emailErr) {
      emailError = emailErr.message;
      console.error(`❌ OTP email FAILED → ${email} | ${emailErr.message}`);
      // Don't fail the request — OTP is saved in DB, user can still try
      // but tell them to check if they have email issues
    }

    // Always return success (OTP is in DB regardless)
    // Include a hint if email failed so user knows to check spam or contact support
    const message = emailSent
      ? 'Verification code sent! Check your inbox and spam/junk folder.'
      : 'Code generated but email delivery failed. Please check your email address or contact support.';

    res.json({ message, emailSent });
  } catch(e) {
    console.error('OTP route error:', e.message);
    res.status(500).json({ error:'Server error: ' + e.message });
  }
});

app.post('/api/auth/verify-otp', authLimiter, async (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email||!code) return res.status(400).json({ error:'Email and code required' });
    const otp = await OTP.findOne({ email, code });
    if (!otp) return res.status(400).json({ error:'Invalid or expired code. Try again.' });
    if (otp.expiresAt < new Date()) return res.status(400).json({ error:'Code expired. Request a new one.' });
    await OTP.deleteMany({ email });
    res.json({ message:'Email verified successfully', verified:true });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.post('/api/auth/register', authLimiter, async (req, res) => {
  try {
    let { name, email, password, phone, referralCode } = req.body;
    // SECURITY: XSS — sanitize stored fields
    name = escapeHtml(name||'');
    email = (email||'').toLowerCase().trim();
    if (!name||!email||!password||!phone) return res.status(400).json({ error:'All fields are required' });
    if (password.length < 6) return res.status(400).json({ error:'Password must be at least 6 characters' });
    if (await User.findOne({ email })) return res.status(400).json({ error:'Email already registered' });
    let referrer = null;
    if (referralCode) {
      referrer = await User.findOne({ referralCode:referralCode.toUpperCase() });
      if (!referrer) return res.status(400).json({ error:'Invalid referral code' });
    }
    const user = await User.create({ name, email, password, phone, referredBy:referralCode?referralCode.toUpperCase():null });
    if (referrer) { referrer.referrals.push(email); await referrer.save(); }
    const accessToken = generateAccessToken(user);
    let refreshToken = null;
    try { refreshToken = await generateRefreshToken(user._id); } catch(e) { console.error('Refresh token error:', e.message); }
    res.status(201).json({ token: accessToken, refreshToken, user:{ id:user._id, name:user.name, email:user.email, role:user.role } });
  } catch(e) { console.error(e); res.status(500).json({ error:'Server error' }); }
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email||!password) return res.status(400).json({ error:'Email and password required' });
    // SECURITY: Enforce string types — block { $gt: "" } NoSQL injection
    if (typeof email !== 'string' || typeof password !== 'string') {
      console.warn(`🚨 NoSQL injection attempt on login from ${(req.headers['x-forwarded-for']||req.socket.remoteAddress||'').split(',')[0]}`);
      return res.status(400).json({ error:'Invalid credentials' });
    }
    const safeEmail = email.toLowerCase().trim().substring(0, 200);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(safeEmail)) return res.status(400).json({ error:'Invalid email format' });
    const user = await User.findOne({ email: safeEmail }).select('+password');
    if (!user||!(await bcrypt.compare(password, user.password))) return res.status(401).json({ error:'Invalid credentials' });
    if (!user.isActive) return res.status(403).json({ error:'Account suspended. Contact support.' });
    try { await applyDailyEarnings(user._id); } catch(e) { console.error('Earnings error:', e.message); }
    // Log login safely
    try {
      const ip = req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown';
      const device = (req.headers['user-agent']||'unknown').substring(0,200);
      await LoginLog.create({ user:user._id, email:user.email, ip, device, status:'success' });
    } catch(e) {}
    // Welcome bonus safely
    try {
      if (!user.welcomeBonusGiven && user.totalDeposits > 0) {
        await User.findByIdAndUpdate(user._id, { welcomeBonusGiven:true, $inc:{ balance:50 } });
        await Transaction.create({ user:user._id, email:user.email, type:'earning', amount:50, label:'🎉 Welcome Bonus', status:'completed' });
      }
    } catch(e) {}
    const accessToken = generateAccessToken(user);
    let refreshToken = null;
    try { refreshToken = await generateRefreshToken(user._id); } catch(e) { console.error('Refresh token error:', e.message); }
    res.json({ token: accessToken, refreshToken, user:{ id:user._id, name:user.name, email:user.email, role:user.role } });
  } catch(e) { console.error('Login error:', e.message); res.status(500).json({ error: 'Login failed: ' + e.message }); }
});

// ═══════════════════════════════════════════════════════════
//  USER ROUTES
// ═══════════════════════════════════════════════════════════
app.get('/api/user/me', protect, async (req, res) => {
  try { res.json({ user: await User.findById(req.user._id) }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.get('/api/user/transactions', protect, async (req, res) => {
  try { res.json({ transactions: await Transaction.find({ user:req.user._id }).sort({ createdAt:-1 }).limit(50) }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.post('/api/user/checkin', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const today = new Date().toDateString();
    if (user.lastCheckin === today) return res.status(400).json({ error:'Already checked in today. Come back tomorrow!' });
    const bonus = 5;
    user.balance = parseFloat((user.balance + bonus).toFixed(2));
    user.lastCheckin = today;
    user.checkinStreak = (user.checkinStreak||0) + 1;
    await user.save();
    await Transaction.create({ user:user._id, email:user.email, type:'earning', amount:bonus, label:`Daily Check-in Bonus — Day ${user.checkinStreak}`, status:'completed' });
    res.json({ message:`✅ Check-in successful! +KSH ${bonus} bonus`, streak:user.checkinStreak, bonus });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.post('/api/user/change-password', protect, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;
    if (!oldPassword||!newPassword) return res.status(400).json({ error:'All fields required' });
    if (newPassword.length < 6) return res.status(400).json({ error:'Password must be at least 6 characters' });
    const user = await User.findById(req.user._id).select('+password');
    if (!(await bcrypt.compare(oldPassword, user.password))) return res.status(400).json({ error:'Current password is incorrect' });
    user.password = newPassword;
    user.passwordChangedAt = new Date();
    user.tokenVersion = (user.tokenVersion||0) + 1; // invalidate all existing tokens
    await user.save();
    await RefreshToken.updateMany({ user:user._id }, { used:true });
    // Issue fresh tokens
    const newAccess = generateAccessToken(user);
    const newRefresh = await generateRefreshToken(user._id);
    res.json({ message:'Password changed. Please login again on other devices.', token:newAccess, refreshToken:newRefresh });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.get('/api/user/messages', protect, async (req, res) => {
  try {
    const msgs = await Message.find({ $or:[{ to:req.user._id },{ isBroadcast:true }] }).sort({ createdAt:-1 }).limit(20);
    res.json({ messages:msgs });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.patch('/api/user/messages/:id/read', protect, async (req, res) => {
  try {
    // SECURITY: IDOR fix — only mark YOUR OWN messages as read
    const msg = await Message.findOne({ _id:req.params.id, $or:[{ to:req.user._id },{ isBroadcast:true }] });
    if (!msg) return res.status(404).json({ error:'Message not found' });
    await Message.findByIdAndUpdate(req.params.id, { isRead:true });
    res.json({ message:'Read' });
  }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ═══════════════════════════════════════════════════════════
//  PUBLIC ROUTES
// ═══════════════════════════════════════════════════════════
app.get('/api/announcements', async (req, res) => {
  try { res.json({ announcements: await Announcement.find({ active:true }).sort({ createdAt:-1 }).limit(5) }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.get('/api/socials', async (req, res) => {
  try { res.json({ socials: await Social.find({ active:true }).sort({ createdAt:1 }) }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ═══════════════════════════════════════════════════════════
//  DEPOSIT
// ═══════════════════════════════════════════════════════════
app.post('/api/deposit/stk', protect, depositLimiter, async (req, res) => {
  try {
    const { phone, tier } = req.body;
    // SECURITY: Block duplicate pending STK push
    const pendingTx = await Transaction.findOne({ user:req.user._id, status:'pending', method:'mpesa' });
    if (pendingTx) {
      const ageMinutes = (Date.now() - new Date(pendingTx.createdAt)) / 60000;
      if (ageMinutes < 5) return res.status(429).json({ error:'You have a pending payment. Wait for it to complete or expire (5 min).' });
      pendingTx.status = 'failed'; await pendingTx.save();
    }
    // Strict server-side validation
    const amount = validateAmount(req.body.amount, 1, 5000000);
    if (!amount) return res.status(400).json({ error:'Invalid deposit amount' });
    const tierInfo = TIERS[tier] || TIERS.starter;
    if (!amount||amount < tierInfo.min) return res.status(400).json({ error:`Minimum deposit for ${tierInfo.label} is KSH ${tierInfo.min.toLocaleString()}` });
    const tel = phone || req.user.phone;
    if (!tel) return res.status(400).json({ error:'Phone number required' });
    const result = await stkPush(tel, amount, 'ImpactVest', `${tierInfo.label} Plan`);
    if (result.ResponseCode !== '0') return res.status(400).json({ error:result.ResponseDescription||'STK push failed' });
    await Transaction.create({ user:req.user._id, email:req.user.email, type:'deposit', amount, label:`Deposit — ${tierInfo.label} Plan`, status:'pending', method:'mpesa', mpesaRef:result.CheckoutRequestID, phone:tel, tier });
    res.json({ message:'STK push sent! Check your phone.', checkoutRequestId:result.CheckoutRequestID });
  } catch(e) {
    const safErr = e.response?.data;
    console.error('STK ERROR:', JSON.stringify(safErr || e.message));
    const msg = safErr?.errorMessage || safErr?.ResultDesc || safErr?.ResponseDescription || (typeof safErr === 'string' ? safErr : null) || e.message || 'M-Pesa request failed. Try again.';
    res.status(500).json({ error: msg });
  }
});

app.post('/api/mpesa/callback/:secret', async (req, res) => {
  try {
    // SECURITY: Validate secret token in URL
    const expectedSecret = process.env.MPESA_CALLBACK_SECRET || 'changeme';
    if (req.params.secret !== expectedSecret) {
      console.warn(`🚨 Callback with WRONG SECRET from IP: ${(req.headers['x-forwarded-for']||req.socket.remoteAddress||'').split(',')[0].trim()}`);
      return res.status(403).json({ ResultCode:1, ResultDesc:'Unauthorized' });
    }

    // SECURITY: Validate request is from Safaricom IP range
    const allowedIPs = ['196.201.214.200','196.201.214.206','196.201.213.100',
      '196.201.214.207','196.201.214.208','196.201.213.101','196.201.212.127','196.201.212.138','::1','127.0.0.1'];
    const reqIP = (req.headers['x-forwarded-for']||req.socket.remoteAddress||'').split(',')[0].trim();
    const isLocal = reqIP === '::1' || reqIP === '127.0.0.1' || reqIP.startsWith('192.168.') || reqIP.startsWith('10.');
    if (!isLocal && process.env.MPESA_ENV !== 'sandbox' && !allowedIPs.includes(reqIP)) {
      console.warn(`⚠️  Callback blocked from unauthorized IP: ${reqIP}`);
      return res.status(403).json({ ResultCode:1, ResultDesc:'Unauthorized' });
    }

    const cb = req.body.Body?.stkCallback;
    if (!cb) return res.json({ ResultCode:0 });
    // SECURITY: Atomic transaction lock — findOneAndUpdate ensures only ONE callback
    // can ever process this tx, even if two arrive simultaneously
    const tx = await Transaction.findOneAndUpdate(
      { mpesaRef: cb.CheckoutRequestID, status: 'pending' },
      { $set: { status: 'processing' } },
      { new: false } // return original doc
    );
    if (!tx) {
      // Either not found OR already processed (not pending) — both safe to ignore
      console.warn(`⚠️  Callback ignored: tx not found or already processed (${cb.CheckoutRequestID})`);
      return res.json({ ResultCode:0 });
    }

    if (cb.ResultCode === 0) {
      // SECURITY: Verify paid amount matches expected amount
      const callbackItems = cb.CallbackMetadata?.Item || [];
      const paidAmount = callbackItems.find(i => i.Name === 'Amount')?.Value;
      if (paidAmount !== undefined && parseFloat(paidAmount) < parseFloat(tx.amount)) {
        console.warn(`⚠️  Amount mismatch! Expected ${tx.amount}, got ${paidAmount} for tx ${tx._id}`);
        tx.status = 'failed';
        tx.label = `[FRAUD] Amount mismatch: paid ${paidAmount} expected ${tx.amount}`;
        await tx.save();
        return res.json({ ResultCode:0 });
      }
      tx.status = 'completed'; await tx.save();
      const user = await User.findById(tx.user);
      if (user) {
        // High machine purchase
        const highMachinePurchaseMatch = tx.label && tx.label.match(/High Machine Purchase: ([a-f0-9]{24})/);
        if (highMachinePurchaseMatch) {
          const machineId = highMachinePurchaseMatch[1];
          const machine = await HighMachine.findById(machineId);
          if (machine) {
            const alreadyOwned = await UserHighMachine.findOne({ user: user._id, machine: machine._id });
            if (!alreadyOwned) {
              await UserHighMachine.create({ user: user._id, machine: machine._id });
              machine.soldCount = (machine.soldCount || 0) + 1;
              await machine.save();
            }
            tx.label = `⚡ Purchased: ${machine.name}`;
          }
        }
        const machinePurchaseMatch = !highMachinePurchaseMatch && tx.label && tx.label.match(/⛏️ Machine Purchase: ([a-f0-9]{24})/);
        if (machinePurchaseMatch) {
          // Machine purchase — create ownership record
          const machineId = machinePurchaseMatch[1];
          const machine = await MiningMachine.findById(machineId);
          if (machine) {
            await UserMachine.create({ user: user._id, machine: machine._id });
            machine.soldCount = (machine.soldCount || 0) + 1;
            await machine.save();
            // Update tx label to be cleaner
            tx.label = `⛏️ Purchased: ${machine.name}`;
            tx.type = 'deposit';
            await tx.save();
          }
        } else {
          // Regular deposit — credit balance
          const oldBalance = user.balance;
          user.balance = parseFloat((user.balance + tx.amount).toFixed(2));
          user.totalDeposits = parseFloat(((user.totalDeposits||0) + tx.amount).toFixed(2));
          user.tier = getTierForAmount(user.totalDeposits);
          await user.save();
          // SECURITY: Audit log every balance change
          console.log(`💰 BALANCE CREDIT | user:${user._id} | ${oldBalance} → ${user.balance} | +${tx.amount} | tx:${tx._id} | cb:${cb.CheckoutRequestID}`);
          if (user.referredBy) {
            const ref = await User.findOne({ referralCode:user.referredBy });
            if (ref) {
              const comm = parseFloat((tx.amount * 0.10).toFixed(2));
              ref.balance = parseFloat((ref.balance + comm).toFixed(2));
              ref.refBonus = parseFloat(((ref.refBonus||0) + comm).toFixed(2));
              await ref.save();
              await Transaction.create({ user:ref._id, email:ref.email, type:'refbonus', amount:comm, label:`Referral from ${user.email}`, status:'completed' });
            }
          }
        }
      }
    } else { tx.status = 'failed'; await tx.save(); }
    res.json({ ResultCode:0 });
  } catch(e) { res.json({ ResultCode:0 }); }
});

app.get('/api/deposit/status/:id', protect, async (req, res) => {
  try {
    const tx = await Transaction.findOne({ mpesaRef:req.params.id, user:req.user._id });
    if (!tx) return res.status(404).json({ error:'Not found' });
    res.json({ status:tx.status, amount:tx.amount });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ═══════════════════════════════════════════════════════════
//  WITHDRAWAL
// ═══════════════════════════════════════════════════════════
app.post('/api/withdraw', protect, withdrawLimiter, async (req, res) => {
  try {
    const { method, phone, bankName, bankAccount } = req.body;
    // SECURITY: Strict amount validation — block negative, zero, float tricks
    const rawAmount = req.body.amount;
    if (rawAmount === undefined || rawAmount === null || String(rawAmount).includes('-') || String(rawAmount).includes('e')) {
      return res.status(400).json({ error:'Invalid withdrawal amount.' });
    }
    const amount = validateAmount(rawAmount, 200, 1000000);
    if (!amount || amount <= 0 || !isFinite(amount)) return res.status(400).json({ error:'Invalid withdrawal amount. Min: KSH 200' });
    // SECURITY: Verify balance is positive before deducting
    const freshUser = await User.findById(req.user._id);
    if (!freshUser || freshUser.balance < amount) {
      return res.status(400).json({ error:'Insufficient balance.' });
    }

    let user = freshUser; // already fetched above

    // ── RULE 1: Must own at least one machine ──
    const ownedMachines = await UserMachine.countDocuments({ user: user._id, isActive: true });
    if (ownedMachines === 0)
      return res.status(400).json({ error:'You must own at least one mining machine before you can withdraw.' });

    // ── RULE 2: M-Pesa phone must match registered phone ──
    if (method === 'mpesa' || !method) {
      const reqPhone = (phone||'').replace(/\s/g,'').replace(/^254/,'0').replace(/^\+254/,'0');
      const regPhone = (user.phone||'').replace(/\s/g,'').replace(/^254/,'0').replace(/^\+254/,'0');
      if (!reqPhone) return res.status(400).json({ error:'M-Pesa phone number is required.' });
      if (reqPhone !== regPhone)
        return res.status(400).json({ error:`Withdrawal must be sent to your registered M-Pesa number ending in ...${regPhone.slice(-4)}` });
    }

    if (amount > user.balance) return res.status(400).json({ error:'Insufficient balance' });

    // SECURITY: Atomic balance deduction — findOneAndUpdate with balance check
    // Prevents two simultaneous withdrawals both passing the balance check
    const updatedUser = await User.findOneAndUpdate(
      { _id: req.user._id, balance: { $gte: amount } }, // only if balance still enough
      { $inc: { balance: -amount, totalWithdrawn: amount } },
      { new: true }
    );
    if (!updatedUser) return res.status(400).json({ error:'Insufficient balance. Please try again.' });

    await Transaction.create({ user:updatedUser._id, email:updatedUser.email, type:'withdrawal', amount, label:`Withdrawal via ${(method||'mpesa').toUpperCase()}`, status:'pending', method, phone });
    console.log(`💸 WITHDRAW | user:${updatedUser._id} | -${amount} | balance:${updatedUser.balance} | method:${method||'mpesa'}`);
    user = updatedUser;
    sendWithdrawalEmail(updatedUser, amount, method);
    res.json({ message:'✅ Withdrawal submitted successfully! Your funds will be sent to your M-Pesa within 24 hours.', newBalance: updatedUser.balance });
  } catch(e) { console.error(e); res.status(500).json({ error:'Server error' }); }
});

// ═══════════════════════════════════════════════════════════
//  ADMIN ROUTES
// ═══════════════════════════════════════════════════════════

// Stats
app.get('/api/admin/stats', protect, adminOnly, async (req, res) => {
  try {
    const today = new Date(); today.setHours(0,0,0,0);
    const [totalUsers,activeUsers,allDep,todayDep,allWD,pendingWD,earned,liability] = await Promise.all([
      User.countDocuments({ role:'user' }),
      User.countDocuments({ role:'user', isActive:true }),
      Transaction.aggregate([{$match:{type:'deposit',status:'completed'}},{$group:{_id:null,t:{$sum:'$amount'}}}]),
      Transaction.aggregate([{$match:{type:'deposit',status:'completed',createdAt:{$gte:today}}},{$group:{_id:null,t:{$sum:'$amount'}}}]),
      Transaction.aggregate([{$match:{type:'withdrawal',status:'completed'}},{$group:{_id:null,t:{$sum:'$amount'}}}]),
      Transaction.find({type:'withdrawal',status:'pending'}).populate('user','name email phone').sort({createdAt:-1}),
      Transaction.aggregate([{$match:{type:'earning'}},{$group:{_id:null,t:{$sum:'$amount'}}}]),
      User.aggregate([{$match:{role:'user'}},{$group:{_id:null,t:{$sum:'$balance'}}}])
    ]);
    const newUsersToday = await User.countDocuments({ role:'user', createdAt:{ $gte:today } });
    res.json({ totalUsers, activeUsers, newUsersToday, totalDeposits:allDep[0]?.t||0, todayDeposits:todayDep[0]?.t||0, totalWithdrawals:allWD[0]?.t||0, pendingWithdrawals:pendingWD, totalEarned:earned[0]?.t||0, systemLiability:liability[0]?.t||0 });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Users
app.get('/api/admin/users', protect, adminOnly, async (req, res) => {
  try {
    const limit = parseInt(req.query.limit)||50;
    const users = await User.find({ role:'user' }).select('-password').sort({ createdAt:-1 }).limit(limit);
    const total = await User.countDocuments({ role:'user' });
    res.json({ users, total });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.get('/api/admin/users/search', protect, adminOnly, async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) return res.json({ users:[] });
    const users = await User.find({ role:'user', $or:[{ name:{$regex:q,$options:'i'} },{ email:{$regex:q,$options:'i'} },{ phone:{$regex:q,$options:'i'} }] }).select('-password').limit(20);
    res.json({ users });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.get('/api/admin/user/:id', protect, adminOnly, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ error:'User not found' });
    const txs = await Transaction.find({ user:user._id }).sort({ createdAt:-1 }).limit(30);
    res.json({ user, transactions:txs });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.patch('/api/admin/user/:id', protect, adminOnly, async (req, res) => {
  try {
    // Whitelist only safe fields — never allow direct balance manipulation from frontend
    const allowed = ['tier','name','phone'];
    const update = {};
    for (const key of allowed) { if (req.body[key] !== undefined) update[key] = req.body[key]; }
    // Balance can ONLY be set by admin with explicit credit endpoint, not general edit
    if (req.body.balance !== undefined) {
      const newBal = validateAmount(req.body.balance, 0, 99999999);
      if (newBal === false) return res.status(400).json({ error:'Invalid balance value' });
      update.balance = newBal;
    }
    const user = await User.findByIdAndUpdate(req.params.id, update, { new:true, runValidators:true }).select('-password');
    if (!user) return res.status(404).json({ error:'User not found' });
    await logAdminAction(req, 'EDIT_USER', user.email, JSON.stringify(update));
    res.json({ message:'User updated', user });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.patch('/api/admin/user/:id/toggle', protect, adminOnly, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error:'User not found' });
    user.isActive = !user.isActive; await user.save();
    res.json({ message:`User ${user.isActive?'activated':'suspended'}` });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.patch('/api/admin/user/:id/reset-password', protect, adminOnly, async (req, res) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword||newPassword.length<6) return res.status(400).json({ error:'Min 6 characters' });
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error:'User not found' });
    user.password = newPassword; await user.save();
    res.json({ message:`Password reset for ${user.name}` });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.post('/api/admin/user/:id/credit', protect, adminOnly, async (req, res) => {
  try {
    const { amount, note } = req.body;
    if (!amount||amount<=0) return res.status(400).json({ error:'Invalid amount' });
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error:'User not found' });
    user.balance = parseFloat((user.balance + parseFloat(amount)).toFixed(2));
    await user.save();
    await Transaction.create({ user:user._id, email:user.email, type:'earning', amount:parseFloat(amount), label:note||'Admin Credit', status:'completed' });
    res.json({ message:`KSH ${amount} credited to ${user.name}` });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.delete('/api/admin/user/:id', protect, adminOnly, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error:'User not found' });
    await Transaction.deleteMany({ user:user._id });
    await User.findByIdAndDelete(req.params.id);
    await logAdminAction(req, 'DELETE_USER', user.email, `Deleted user and ${(await Transaction.countDocuments({user:user._id}))} transactions`);
    res.json({ message:`User ${user.name} deleted` });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Transactions
app.get('/api/admin/transactions', protect, adminOnly, async (req, res) => {
  try {
    const { type, status, search } = req.query;
    const filter = {};
    if (type) filter.type = type;
    if (status) filter.status = status;
    if (search) filter.email = { $regex:search, $options:'i' };
    const txs = await Transaction.find(filter).sort({ createdAt:-1 }).limit(200).populate('user','name email');
    res.json({ transactions:txs });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Deposits
app.patch('/api/admin/deposit/:id', protect, adminOnly, async (req, res) => {
  try {
    const { action } = req.body;
    const tx = await Transaction.findById(req.params.id);
    if (!tx||tx.type!=='deposit') return res.status(404).json({ error:'Not found' });
    if (action==='approve') {
      tx.status='completed'; await tx.save();
      const user = await User.findById(tx.user);
      if (user) { user.balance=parseFloat((user.balance+tx.amount).toFixed(2)); user.totalDeposits=parseFloat(((user.totalDeposits||0)+tx.amount).toFixed(2)); user.tier=getTierForAmount(user.totalDeposits); await user.save(); }
    } else { tx.status='failed'; await tx.save(); }
    await logAdminAction(req, `DEPOSIT_${action.toUpperCase()}`, tx._id.toString(), `Amount: KSH ${tx.amount}`);
    res.json({ message:`Deposit ${action}d` });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Withdrawals
app.patch('/api/admin/withdrawal/:id', protect, adminOnly, async (req, res) => {
  try {
    const { action } = req.body;
    const tx = await Transaction.findById(req.params.id);
    if (!tx||tx.type!=='withdrawal') return res.status(404).json({ error:'Not found' });
    if (action==='approve') { tx.status='completed'; await tx.save(); }
    else if (action==='reject') {
      tx.status='rejected'; await tx.save();
      const user = await User.findById(tx.user);
      if (user) { user.balance=parseFloat((user.balance+tx.amount).toFixed(2)); user.totalWithdrawn=parseFloat(((user.totalWithdrawn||0)-tx.amount).toFixed(2)); await user.save(); }
    }
    await logAdminAction(req, `WITHDRAWAL_${action.toUpperCase()}`, tx._id.toString(), `Amount: KSH ${tx.amount}`);
    res.json({ message:`Withdrawal ${action}d` });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Messages
app.get('/api/admin/messages', protect, adminOnly, async (req, res) => {
  try { res.json({ messages: await Message.find().sort({ createdAt:-1 }).limit(100) }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.post('/api/admin/message/user/:id', protect, adminOnly, async (req, res) => {
  try {
    const { subject, body } = req.body;
    if (!subject||!body) return res.status(400).json({ error:'Subject and body required' });
    const idOrEmail = req.params.id;
    let user = null;
    if (idOrEmail.includes('@')) { user = await User.findOne({ email:idOrEmail }); }
    else { try { user = await User.findById(idOrEmail); } catch(e) {} if (!user) user = await User.findOne({ email:idOrEmail }); }
    if (!user) return res.status(404).json({ error:'User not found. Use their email address.' });
    // Save in-app message
    await Message.create({ to:user._id, toEmail:user.email, subject, body, isBroadcast:false });
    // Send real email
    await sendEmail(user.email, subject, buildEmailTemplate(user.name, subject, body));
    console.log(`📧 Email sent to ${user.email}`);
    res.json({ message:`✅ Email sent to ${user.name} (${user.email})` });
  } catch(e) { console.error('Email error:', e.message); res.status(500).json({ error:'Failed to send email: ' + e.message }); }
});

app.post('/api/admin/message/broadcast', protect, adminOnly, async (req, res) => {
  try {
    const { subject, body } = req.body;
    if (!subject||!body) return res.status(400).json({ error:'Subject and body required' });
    // Save in-app broadcast
    await Message.create({ to:null, toEmail:'all', subject, body, isBroadcast:true });
    // Send real email to ALL active users
    const users = await User.find({ role:'user', isActive:true }).select('name email');
    let sent = 0, failed = 0;
    for (const user of users) {
      try {
        await sendEmail(user.email, subject, buildEmailTemplate(user.name, subject, body));
        sent++;
        // Small delay to avoid Gmail rate limits
        await new Promise(r => setTimeout(r, 100));
      } catch(e) {
        failed++;
        console.error(`Failed to send to ${user.email}:`, e.message);
      }
    }
    console.log(`📢 Broadcast: ${sent} sent, ${failed} failed`);
    res.json({ message:`✅ Broadcast sent to ${sent} users${failed>0?' ('+failed+' failed)':''}` });
  } catch(e) { console.error(e); res.status(500).json({ error:'Server error' }); }
});

// Announcements
app.get('/api/admin/announcements', protect, adminOnly, async (req, res) => {
  try { res.json({ announcements: await Announcement.find().sort({ createdAt:-1 }) }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});
app.post('/api/admin/announcements', protect, adminOnly, async (req, res) => {
  try { const ann = await Announcement.create(req.body); res.json({ message:'Created', ann }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});
app.delete('/api/admin/announcements/:id', protect, adminOnly, async (req, res) => {
  try { await Announcement.findByIdAndDelete(req.params.id); res.json({ message:'Deleted' }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Social links
app.get('/api/admin/socials', protect, adminOnly, async (req, res) => {
  try { res.json({ socials: await Social.find().sort({ createdAt:1 }) }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});
app.post('/api/admin/socials', protect, adminOnly, async (req, res) => {
  try { const s = await Social.create(req.body); res.json({ message:'Added', social:s }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});
app.patch('/api/admin/socials/:id', protect, adminOnly, async (req, res) => {
  try { const s = await Social.findByIdAndUpdate(req.params.id, req.body, {new:true}); res.json({ social:s }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});
app.delete('/api/admin/socials/:id', protect, adminOnly, async (req, res) => {
  try { await Social.findByIdAndDelete(req.params.id); res.json({ message:'Deleted' }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Settings
app.get('/api/admin/settings', protect, adminOnly, async (req, res) => {
  try { const docs = await Settings.find(); const s={}; docs.forEach(d=>s[d.key]=d.value); res.json(s); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});
app.post('/api/admin/settings', protect, adminOnly, async (req, res) => {
  try { for (const [k,v] of Object.entries(req.body)) await Settings.findOneAndUpdate({key:k},{value:v},{upsert:true}); res.json({message:'Saved'}); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Activity log
app.get('/api/admin/activity', protect, adminOnly, async (req, res) => {
  try { res.json({ logs: await Activity.find().sort({ createdAt:-1 }).limit(100).populate('user','name email') }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Security
app.get('/api/admin/security', protect, adminOnly, async (req, res) => {
  try {
    const today = new Date(); today.setHours(0,0,0,0);
    const oneHourAgo = new Date(Date.now() - 60*60*1000);
    const [blockedUsers, failedTx, largeWithdrawals, newUsersToday, recentLogins, adminLogs] = await Promise.all([
      User.countDocuments({ role:'user', isActive:false }),
      Transaction.countDocuments({ status:'failed' }),
      Transaction.find({ type:'withdrawal', amount:{ $gte:10000 } }).sort({ createdAt:-1 }).limit(10).populate('user','name email'),
      User.countDocuments({ role:'user', createdAt:{ $gte:today } }),
      LoginLog.find({ createdAt:{ $gte:oneHourAgo } }).sort({ createdAt:-1 }).limit(20).populate('user','name email'),
      AdminLog.find().sort({ createdAt:-1 }).limit(20)
    ]);
    // Suspicious: many failed tx from same user
    const suspiciousUsers = await Transaction.aggregate([
      { $match: { status:'failed', createdAt:{ $gte:today } } },
      { $group: { _id:'$user', count:{ $sum:1 } } },
      { $match: { count:{ $gte:3 } } }
    ]);
    res.json({ blockedUsers, failedTx, largeWithdrawals, newUsersToday, recentLogins, adminLogs, suspiciousUsers });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Bulk tools
app.post('/api/admin/bulk/block', protect, adminOnly, async (req, res) => {
  try { const { userIds } = req.body; await User.updateMany({ _id:{ $in:userIds } }, { isActive:false }); res.json({ message:`${userIds.length} users blocked` }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});
app.post('/api/admin/bulk/credit-all', protect, adminOnly, async (req, res) => {
  try {
    const { amount, note } = req.body;
    if (!amount||amount<=0) return res.status(400).json({ error:'Invalid amount' });
    const users = await User.find({ role:'user', isActive:true });
    for (const user of users) {
      user.balance = parseFloat((user.balance + parseFloat(amount)).toFixed(2));
      await user.save();
      await Transaction.create({ user:user._id, email:user.email, type:'earning', amount:parseFloat(amount), label:note||'Admin Bonus', status:'completed' });
    }
    res.json({ message:`KSH ${amount} credited to ${users.length} users` });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Export CSV
app.get('/api/admin/export/users', protect, adminOnly, async (req, res) => {
  try {
    const users = await User.find({ role:'user' }).select('-password').sort({ createdAt:-1 });
    const csv = ['Name,Email,Phone,Balance,Total Deposits,Tier,Status,Joined',
      ...users.map(u=>`${u.name},${u.email},${u.phone||''},${u.balance},${u.totalDeposits},${u.tier},${u.isActive?'Active':'Blocked'},${new Date(u.createdAt).toLocaleDateString()}`)
    ].join('\n');
    res.setHeader('Content-Type','text/csv');
    res.setHeader('Content-Disposition','attachment; filename=users.csv');
    res.send(csv);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Seed admin
app.post('/api/admin/seed', async (req, res) => {
  try {
    const { secretKey } = req.body;
    if (secretKey !== process.env.ADMIN_SECRET_KEY) return res.status(403).json({ error:'Invalid secret key' });
    if (await User.findOne({ email:process.env.ADMIN_EMAIL })) return res.status(400).json({ error:'Admin already exists' });
    await User.create({ name:'Admin', email:process.env.ADMIN_EMAIL, password:process.env.ADMIN_PASSWORD, phone:'0700000000', role:'admin' });
    res.json({ message:'Admin created' });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});


// ═══════════════════════════════════════════════════════════
//  ADMIN UPDATE OWN CREDENTIALS (from admin panel)
// ═══════════════════════════════════════════════════════════
app.post('/api/admin/update-credentials', protect, adminOnly, async (req, res) => {
  try {
    const { email, password, currentPassword } = req.body;
    if (!email || !password || !currentPassword)
      return res.status(400).json({ error: 'All fields required' });
    if (typeof email !== 'string' || typeof password !== 'string' || typeof currentPassword !== 'string')
      return res.status(400).json({ error: 'Invalid input' });
    if (password.length < 8)
      return res.status(400).json({ error: 'Password must be at least 8 characters' });
    const cleanEmail = email.toLowerCase().trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail))
      return res.status(400).json({ error: 'Invalid email format' });
    // Check if email is taken by another user
    const existing = await User.findOne({ email: cleanEmail });
    if (existing && existing._id.toString() !== req.user._id.toString())
      return res.status(400).json({ error: 'Email already in use by another account' });
    const admin = await User.findById(req.user._id).select('+password');
    if (!admin) return res.status(404).json({ error: 'Admin not found' });
    const match = await bcrypt.compare(currentPassword, admin.password);
    if (!match) return res.status(401).json({ error: 'Current password is incorrect' });
    // Use direct update to avoid schema hook issues
    const newHash = await bcrypt.hash(password, 12);
    await User.findByIdAndUpdate(req.user._id, {
      email: cleanEmail,
      password: newHash,
      tokenVersion: (admin.tokenVersion || 0) + 1,
      passwordChangedAt: new Date()
    });
    console.log(`[ADMIN] Credentials updated to ${cleanEmail}`);
    res.json({ message: 'Credentials updated successfully' });
  } catch(e) { console.error('[ADMIN CREDS]', e); res.status(500).json({ error: 'Server error', detail: e.message }); }
});

// ═══════════════════════════════════════════════════════════
//  PUBLIC PLATFORM STATS (builds trust)
// ═══════════════════════════════════════════════════════════
app.get('/api/stats/public', async (req, res) => {
  try {
    // Cache for 5 minutes
    if (StatsCache.data && StatsCache.updatedAt && (Date.now() - StatsCache.updatedAt) < 5*60*1000) {
      return res.json(StatsCache.data);
    }
    const [totalUsers, totalPaid, totalDeposits, recentWD] = await Promise.all([
      User.countDocuments({ role:'user', isActive:true }),
      Transaction.aggregate([{$match:{type:'withdrawal',status:'completed'}},{$group:{_id:null,t:{$sum:'$amount'}}}]),
      Transaction.aggregate([{$match:{type:'deposit',status:'completed'}},{$group:{_id:null,t:{$sum:'$amount'}}}]),
      Transaction.find({ type:'withdrawal', status:'completed' }).sort({ createdAt:-1 }).limit(5).populate('user','name')
    ]);
    // Get admin-customized social proof
    const spDocs = await SocialProof.find({ key: { $in: ['extraInvestors','extraPaidOut','extraDeposited','fakePayouts','apkExtraDownloads'] } });
    const sp = {};
    spDocs.forEach(d => sp[d.key] = d.value);
    
    const extraInvestors = sp.extraInvestors || 2847;
    const extraPaidOut = sp.extraPaidOut || 4850000;
    const extraDeposited = sp.extraDeposited || 12400000;
    const fakePayoutsData = sp.fakePayouts || [
      { name:'James M...', amount:45000 },
      { name:'Grace W...', amount:28500 },
      { name:'Peter K...', amount:15200 },
      { name:'Faith N...', amount:8900 },
      { name:'David O...', amount:12400 },
    ];
    
    const fakePayouts = fakePayoutsData.map((p,i)=>({ name:p.name, amount:p.amount, date:new Date(Date.now()-(i+1)*2*60*60*1000) }));
    const realPayouts = recentWD.map(t=>({ name:(t.user?.name||'Investor').split(' ')[0]+'...', amount:t.amount, date:t.createdAt }));
    
    StatsCache.data = {
      totalInvestors: totalUsers + extraInvestors,
      totalPaidOut:   (totalPaid[0]?.t || 0) + extraPaidOut,
      totalDeposited: (totalDeposits[0]?.t || 0) + extraDeposited,
      recentPayouts:  [...fakePayouts, ...realPayouts].slice(0,5)
    };
    StatsCache.updatedAt = Date.now();
    res.json(StatsCache.data);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ═══════════════════════════════════════════════════════════
//  KYC
// ═══════════════════════════════════════════════════════════
app.post('/api/user/kyc', protect, async (req, res) => {
  try {
    const { docType, docUrl } = req.body;
    if (!docType||!docUrl) return res.status(400).json({ error:'Document type and URL required' });
    await KYC.findOneAndUpdate({ user:req.user._id }, { docType, docUrl, status:'pending', note:'' }, { upsert:true });
    await User.findByIdAndUpdate(req.user._id, { kycStatus:'pending' });
    res.json({ message:'KYC submitted for review' });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.get('/api/user/kyc', protect, async (req, res) => {
  try {
    const kyc = await KYC.findOne({ user:req.user._id });
    res.json({ kyc });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ═══════════════════════════════════════════════════════════
//  LOGIN HISTORY
// ═══════════════════════════════════════════════════════════
app.get('/api/user/login-history', protect, async (req, res) => {
  try {
    const logs = await LoginLog.find({ user:req.user._id }).sort({ createdAt:-1 }).limit(10);
    res.json({ logs });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ═══════════════════════════════════════════════════════════
//  WITHDRAWAL CONFIRMATION EMAIL
// ═══════════════════════════════════════════════════════════
async function sendWithdrawalEmail(user, amount, method) {
  try {
    const html = `
      <div style="font-family:Arial,sans-serif;max-width:580px;margin:0 auto;background:#0d0f14;color:#e4eaf5;border-radius:16px;overflow:hidden">
        <div style="background:linear-gradient(135deg,#1a1608,#141b28);padding:28px 32px;border-bottom:1px solid #2a3548;text-align:center">
          <div style="font-size:22px;font-weight:700;color:#c9a84c">ImpactVest Global</div>
          <p style="color:#6b7e99;font-size:12px;margin-top:6px">Withdrawal Request Received</p>
        </div>
        <div style="padding:32px">
          <p style="color:#6b7e99;font-size:14px;margin-bottom:16px">Hello <strong style="color:#e4eaf5">${user.name}</strong>,</p>
          <div style="background:#1e2638;border-left:3px solid #c9a84c;border-radius:0 10px 10px 0;padding:20px 24px;margin-bottom:20px">
            <div style="font-size:13px;color:#6b7e99;margin-bottom:6px">Withdrawal Amount</div>
            <div style="font-size:32px;font-weight:700;color:#c9a84c;font-family:monospace">KSH ${parseFloat(amount).toLocaleString()}</div>
            <div style="font-size:12px;color:#6b7e99;margin-top:8px">via ${(method||'M-Pesa').toUpperCase()}</div>
          </div>
          <p style="font-size:13px;color:#6b7e99;line-height:1.8">Your withdrawal request has been received and is being processed. You will receive your funds within <strong style="color:#e4eaf5">24 hours</strong>.</p>
          <p style="font-size:12px;color:#4a6080;margin-top:16px">If you did not make this request, contact support immediately.</p>
        </div>
        <div style="background:#0c1018;padding:20px 32px;border-top:1px solid #2a3548;text-align:center">
          <p style="color:#6b7e99;font-size:11px">© 2026 ImpactVest Global</p>
        </div>
      </div>`;
    await sendEmail(user.email, 'Withdrawal Request Received — KSH ' + amount, html);
  } catch(e) { console.error('WD email error:', e.message); }
}

// ═══════════════════════════════════════════════════════════
//  LEADERBOARD
// ═══════════════════════════════════════════════════════════
// Default fake leaderboard data
const DEFAULT_EARNERS = [
  { name:'James M...', totalEarned:284500, tier:'elite', streak:45 },
  { name:'Grace W...', totalEarned:196800, tier:'vip', streak:38 },
  { name:'Peter K...', totalEarned:143200, tier:'diamond', streak:30 },
  { name:'Faith N...', totalEarned:98400, tier:'platinum', streak:27 },
  { name:'David O...', totalEarned:76500, tier:'diamond', streak:22 },
];
const DEFAULT_REFERRERS = [
  { name:'James M...', refBonus:142000, referrals:28 },
  { name:'Grace W...', refBonus:98500, referrals:19 },
  { name:'Peter K...', refBonus:67200, referrals:13 },
  { name:'Faith N...', refBonus:45800, referrals:9 },
  { name:'David O...', refBonus:32100, referrals:6 },
];

app.get('/api/leaderboard', protect, async (req, res) => {
  try {
    // Get admin-customized fake data or use defaults
    const [spEarners, spReferrers, realEarnersData, realReferrersData] = await Promise.all([
      SocialProof.findOne({ key:'fakeEarners' }),
      SocialProof.findOne({ key:'fakeReferrers' }),
      User.find({ role:'user', isActive:true }).select('name totalEarned tier checkinStreak').sort({ totalEarned:-1 }).limit(5),
      User.find({ role:'user', isActive:true }).select('name refBonus referrals').sort({ refBonus:-1 }).limit(5)
    ]);

    const fakeEarners = (spEarners?.value || DEFAULT_EARNERS).map((u,i)=>({ rank:i+1, ...u }));
    const fakeReferrers = (spReferrers?.value || DEFAULT_REFERRERS).map((u,i)=>({ rank:i+1, ...u }));

    // Only show real users NOT in fake list and with earnings > 0
    const fakeNames = fakeEarners.map(f=>f.name.toLowerCase());
    const realEarners = realEarnersData
      .filter(u => !fakeNames.some(fn => u.name.toLowerCase().startsWith(fn.replace('...','').trim())))
      .map((u,i)=>({ rank:fakeEarners.length+i+1, name:u.name.split(' ')[0]+'...', totalEarned:u.totalEarned, tier:u.tier, streak:u.checkinStreak||0 }));
    const realReferrers = realReferrersData
      .map((u,i)=>({ rank:fakeReferrers.length+i+1, name:u.name.split(' ')[0]+'...', refBonus:u.refBonus||0, referrals:(u.referrals||[]).length }));

    res.json({
      topEarners: [...fakeEarners, ...realEarners].slice(0,10),
      topReferrers: [...fakeReferrers, ...realReferrers].slice(0,10)
    });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ═══════════════════════════════════════════════════════════
//  ADMIN KYC MANAGEMENT
// ═══════════════════════════════════════════════════════════
app.get('/api/admin/kyc', protect, adminOnly, async (req, res) => {
  try {
    const kycs = await KYC.find().sort({ createdAt:-1 }).populate('user','name email phone');
    res.json({ kycs });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.patch('/api/admin/kyc/:id', protect, adminOnly, async (req, res) => {
  try {
    const { status, note } = req.body;
    const kyc = await KYC.findByIdAndUpdate(req.params.id, { status, note }, { new:true }).populate('user','name email');
    if (kyc) {
      await User.findByIdAndUpdate(kyc.user._id, { kycStatus: status });
      // Email user about KYC decision
      const msg = status==='verified'
        ? 'Your identity has been verified successfully. You now have full access to all features.'
        : `Your KYC was rejected. Reason: ${note||'Please resubmit with clearer documents.'}`;
      await sendEmail(kyc.user.email, `KYC ${status==='verified'?'Approved ✅':'Rejected ❌'} — ImpactVest`, `
        <div style="font-family:Arial,sans-serif;max-width:500px;margin:0 auto;background:#0d0f14;color:#e4eaf5;padding:32px;border-radius:16px">
          <h2 style="color:${status==='verified'?'#1fd4b0':'#e05a5a'}">${status==='verified'?'✅ KYC Verified':'❌ KYC Rejected'}</h2>
          <p style="color:#6b7e99">${msg}</p>
        </div>`);
    }
    res.json({ message:`KYC ${status}` });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});


// ── REFRESH TOKEN ──
app.post('/api/auth/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(401).json({ error:'Refresh token required' });
    const stored = await RefreshToken.findOne({ token:refreshToken, used:false });
    if (!stored || stored.expiresAt < new Date())
      return res.status(401).json({ error:'Invalid or expired refresh token. Please login again.' });
    const user = await User.findById(stored.user);
    if (!user||!user.isActive) return res.status(401).json({ error:'Account not found or suspended' });
    // Rotate: mark old as used, issue new
    stored.used = true; await stored.save();
    const newRefresh = await generateRefreshToken(user._id);
    const accessToken = generateAccessToken(user);
    res.json({ token: accessToken, refreshToken: newRefresh });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ── LOGOUT (invalidate refresh token) ──
app.post('/api/auth/logout', protect, async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) await RefreshToken.findOneAndUpdate({ token:refreshToken }, { used:true });
    res.json({ message:'Logged out successfully' });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ── LOGOUT ALL DEVICES (increment tokenVersion) ──
app.post('/api/auth/logout-all', protect, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.user._id, { $inc:{ tokenVersion:1 } });
    await RefreshToken.updateMany({ user:req.user._id }, { used:true });
    res.json({ message:'Logged out from all devices' });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ── ADMIN ROTATE ALL TOKENS (force all users to re-login) ──
app.post('/api/admin/security/rotate-tokens', protect, adminOnly, async (req, res) => {
  try {
    await User.updateMany({ role:'user' }, { $inc:{ tokenVersion:1 } });
    await RefreshToken.updateMany({}, { used:true });
    await logAdminAction(req, 'ROTATE_ALL_TOKENS', 'all_users', 'Forced all users to re-login');
    res.json({ message:'All user tokens invalidated. Users must re-login.' });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Admin logs
app.get('/api/admin/logs', protect, adminOnly, async (req, res) => {
  try {
    const logs = await AdminLog.find().sort({ createdAt:-1 }).limit(100);
    res.json({ logs });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});


// ═══════════════════════════════════════════════════════════
//  APK
// ═══════════════════════════════════════════════════════════
app.get('/api/apk/latest', async (req, res) => {
  try {
    const apk = await APK.findOne({ active:true }).sort({ createdAt:-1 });
    if (!apk) return res.json({ apk:null });
    const spApk = await SocialProof.findOne({ key:'apkExtraDownloads' });
    const extraDl = spApk?.value || 20000;
    res.json({ apk:{ _id:apk._id, version:apk.version, url:apk.url, size:apk.size, changelog:apk.changelog, filename:apk.filename, downloads:(apk.downloads||0)+extraDl } });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.post('/api/apk/download/:id', async (req, res) => {
  try {
    // SECURITY: only increment if APK exists and is active
    const apk = await APK.findOne({ _id:req.params.id, active:true });
    if (!apk) return res.status(404).json({ error:'Not found' });
    await APK.findByIdAndUpdate(req.params.id, { $inc:{ downloads:1 } });
    res.json({ ok:true });
  }
  catch(e) { res.json({ ok:true }); }
});

app.get('/api/admin/apk', protect, adminOnly, async (req, res) => {
  try { res.json({ apks: await APK.find().sort({ createdAt:-1 }) }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.post('/api/admin/apk', protect, adminOnly, async (req, res) => {
  try {
    const { version, url, size, changelog, filename } = req.body;
    if (!version||!url||!filename) return res.status(400).json({ error:'Version, filename and URL required' });
    await APK.updateMany({}, { active:false });
    const apk = await APK.create({ version, url, size:size||'', changelog:changelog||'', filename, active:true });
    await logAdminAction(req, 'UPLOAD_APK', version, 'New APK uploaded');
    res.json({ message:'APK v'+version+' published', apk });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.delete('/api/admin/apk/:id', protect, adminOnly, async (req, res) => {
  try { await APK.findByIdAndDelete(req.params.id); res.json({ message:'Deleted' }); }
  catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.patch('/api/admin/apk/:id/activate', protect, adminOnly, async (req, res) => {
  try {
    await APK.updateMany({}, { active:false });
    await APK.findByIdAndUpdate(req.params.id, { active:true });
    res.json({ message:'APK set as active' });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});


// ═══════════════════════════════════════════════════════════
//  MINING MACHINE ROUTES
// ═══════════════════════════════════════════════════════════

// GET all active machines (public / user)
// ── COMBINED MINING DATA (one call instead of 4) ──
app.get('/api/mining/all', protect, async (req, res) => {
  try {
    const userId = req.user._id;
    const now = Date.now();
    // Run all 4 queries in parallel
    const [shopMachines, ownedMachines, highMachines, ownedHighMachines] = await Promise.all([
      MiningMachine.find({ isActive:true }).sort({ price:1 }).lean(),
      UserMachine.find({ user:userId, isActive:true }).populate('machine').sort({ purchasedAt:-1 }).lean(),
      HighMachine.find({ isActive:true }).sort({ createdAt:-1 }).lean(),
      UserHighMachine.find({ user:userId, isActive:true }).populate('machine').lean(),
    ]);
    // Process owned machines
    const myMachines = ownedMachines.map(um => {
      const durationMs = (um.machine.durationHours || 24) * 3600 * 1000;
      const lastMined = um.lastMinedAt ? new Date(um.lastMinedAt).getTime() : 0;
      const elapsed = now - lastMined;
      const canMine = elapsed >= durationMs;
      const cooldownLeft = canMine ? 0 : Math.ceil((durationMs - elapsed) / 1000);
      return { _id:um._id, machine:um.machine, purchasedAt:um.purchasedAt, lastMinedAt:um.lastMinedAt, totalEarned:um.totalEarned, canMine, cooldownLeft };
    });
    // Process owned high machines
    const myHighMachines = ownedHighMachines.map(um => ({
      _id:um._id, claimed:um.claimed, claimedAt:um.claimedAt, purchasedAt:um.purchasedAt, machine:um.machine,
    }));
    res.json({ shopMachines, myMachines, highMachines, myHighMachines });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.get('/api/mining/machines', protect, async (req, res) => {
  try {
    const machines = await MiningMachine.find({ isActive:true }).sort({ price:1 });
    res.json(machines);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// GET user's owned machines with mining status
app.get('/api/mining/my-machines', protect, async (req, res) => {
  try {
    const owned = await UserMachine.find({ user:req.user._id, isActive:true })
      .populate('machine')
      .sort({ purchasedAt:-1 });

    const now = Date.now();
    const result = owned.map(um => {
      const durationMs = (um.machine.durationHours || 24) * 3600 * 1000;
      const lastMined = um.lastMinedAt ? um.lastMinedAt.getTime() : 0;
      const elapsed = now - lastMined;
      const canMine = elapsed >= durationMs;
      const cooldownLeft = canMine ? 0 : Math.ceil((durationMs - elapsed) / 1000); // seconds left
      return {
        _id: um._id,
        machine: um.machine,
        purchasedAt: um.purchasedAt,
        lastMinedAt: um.lastMinedAt,
        totalEarned: um.totalEarned,
        canMine,
        cooldownLeft, // seconds
      };
    });
    res.json(result);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// POST buy a machine (deduct from balance)
app.post('/api/mining/buy/:machineId', protect, depositLimiter, async (req, res) => {
  try {
    // SECURITY: Block duplicate pending STK
    const pendingTx = await Transaction.findOne({ user:req.user._id, status:'pending', method:'mpesa' });
    if (pendingTx) {
      const ageMinutes = (Date.now() - new Date(pendingTx.createdAt)) / 60000;
      if (ageMinutes < 5) return res.status(429).json({ error:'You have a pending payment. Please complete it first.' });
      pendingTx.status = 'failed'; await pendingTx.save();
    }
    const machine = await MiningMachine.findById(req.params.machineId);
    if (!machine || !machine.isActive) return res.status(404).json({ error:'Machine not found or unavailable' });

    const { phone } = req.body;
    const user = await User.findById(req.user._id);
    const tel = phone || user.phone;
    if (!tel) return res.status(400).json({ error:'Phone number required for M-Pesa payment' });

    // Trigger STK Push for machine price
    const result = await stkPush(tel, machine.price, 'ImpactVest', `${machine.name} Miner`);
    if (result.ResponseCode !== '0') return res.status(400).json({ error: result.ResponseDescription || 'STK push failed' });

    // Store pending transaction with machineId in label so callback can pick it up
    await Transaction.create({
      user: user._id,
      email: user.email,
      type: 'deposit',
      amount: machine.price,
      label: `⛏️ Machine Purchase: ${machine._id}`,   // callback reads this
      status: 'pending',
      method: 'mpesa',
      mpesaRef: result.CheckoutRequestID,
      phone: tel,
    });

    res.json({ message:`📱 STK Push sent to ${tel}! Enter M-Pesa PIN to complete purchase.`, checkoutRequestId: result.CheckoutRequestID });
  } catch(e) {
    const safErr = e.response?.data;
    console.error('MACHINE STK ERROR:', JSON.stringify(safErr || e.message));
    const msg = safErr?.errorMessage || safErr?.ResultDesc || e.message || 'M-Pesa request failed. Try again.';
    res.status(500).json({ error: msg });
  }
});

// POST mine — user claims earnings from a machine
app.post('/api/mining/mine/:userMachineId', protect, mineLimiter, async (req, res) => {
  try {
    // SECURITY: Atomic lock — atomically check AND update lastMinedAt in one operation
    // This prevents two simultaneous requests both passing the cooldown check
    const now = new Date();
    const um = await UserMachine.findOne({
      _id: req.params.userMachineId,
      user: req.user._id,   // IDOR protection — must be YOUR machine
      isActive: true
    }).populate('machine');
    if (!um) return res.status(404).json({ error:'Machine not found in your account' });

    // SECURITY: Verify machine is still active in DB (not tampered)
    const machine = await MiningMachine.findById(um.machine._id);
    if (!machine || !machine.isActive) return res.status(400).json({ error:'Machine is no longer active' });

    const durationMs = (machine.durationHours || 24) * 3600 * 1000;
    const lastMined = um.lastMinedAt ? um.lastMinedAt.getTime() : 0;
    if (now.getTime() - lastMined < durationMs) {
      const secsLeft = Math.ceil((durationMs - (now.getTime() - lastMined)) / 1000);
      return res.status(400).json({ error:`⏳ Come back in ${Math.floor(secsLeft/3600)}h ${Math.floor((secsLeft%3600)/60)}m to mine again!`, cooldownLeft: secsLeft });
    }

    // SECURITY: Earning comes ONLY from DB machine record — never from client
    const earned = machine.dailyEarning;
    if (!earned || earned <= 0) return res.status(400).json({ error:'Invalid machine earning value' });

    // SECURITY: Atomic update — set lastMinedAt while checking it hasn't changed
    const locked = await UserMachine.findOneAndUpdate(
      { _id: um._id, user: req.user._id, lastMinedAt: um.lastMinedAt },
      { $set: { lastMinedAt: now }, $inc: { totalEarned: earned } },
      { new: true }
    );
    if (!locked) return res.status(429).json({ error:'Mining already in progress. Try again.' });

    // Credit balance
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { $inc: { balance: earned, totalEarned: earned } },
      { new: true }
    );

    await Transaction.create({ user:user._id, email:user.email, type:'earning', amount:earned, label:`⛏️ Mining Reward — ${machine.name}`, status:'completed' });
    console.log(`⛏️  MINE | user:${user._id} | +${earned} | machine:${machine._id} | balance:${user.balance}`);
    res.json({ message:`💰 +KSH ${earned.toLocaleString()} mined from ${machine.name}!`, earned, newBalance: user.balance });
  } catch(e) { console.error(e); res.status(500).json({ error:'Server error' }); }
});

// ─── ADMIN MACHINE MANAGEMENT ──────────────────────────────

// GET all machines (admin)
app.get('/api/admin/machines', protect, adminOnly, async (req, res) => {
  try {
    const machines = await MiningMachine.find().sort({ createdAt:-1 });
    res.json(machines);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// POST create machine (admin)
app.post('/api/admin/machines', protect, adminOnly, async (req, res) => {
  try {
    const { name, description, imageUrl, price, dailyEarning, durationHours, totalSlots, category, hashrate, power } = req.body;
    if (!name || !price || !dailyEarning) return res.status(400).json({ error:'name, price, dailyEarning required' });
    const m = await MiningMachine.create({ name, description, imageUrl, price, dailyEarning, durationHours:durationHours||24, totalSlots:totalSlots||100, category:category||'ASIC', hashrate:hashrate||'', power:power||'' });
    await logAdminAction(req, 'ADD_MACHINE', name, `Added mining machine ${name} @ KSH ${price}`);
    res.json(m);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// PUT update machine (admin)
app.put('/api/admin/machines/:id', protect, adminOnly, async (req, res) => {
  try {
    const { name, description, imageUrl, price, dailyEarning, durationHours, totalSlots, category, hashrate, power, isActive, soldCount } = req.body;
    const update = { name, description, imageUrl, price, dailyEarning, durationHours, totalSlots, category, hashrate, power, isActive };
    if (soldCount !== undefined) update.soldCount = parseInt(soldCount)||0;
    const m = await MiningMachine.findByIdAndUpdate(req.params.id, update, { new:true });
    if (!m) return res.status(404).json({ error:'Not found' });
    await logAdminAction(req, 'EDIT_MACHINE', m.name, `Edited machine ${m.name}`);
    res.json(m);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// DELETE machine (admin)

// Admin: Get all users who own a specific machine
app.get('/api/admin/machines/:id/owners', protect, adminOnly, async (req, res) => {
  try {
    const owners = await UserMachine.find({ machine:req.params.id, isActive:true })
      .populate('user', 'name email phone balance createdAt')
      .sort({ purchasedAt:-1 });
    res.json(owners.map(um => ({
      userMachineId: um._id,
      purchasedAt: um.purchasedAt,
      lastMinedAt: um.lastMinedAt,
      totalEarned: um.totalEarned,
      user: um.user,
    })));
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Admin: Get ALL user-machine ownership (full list)
app.get('/api/admin/machine-owners', protect, adminOnly, async (req, res) => {
  try {
    const owners = await UserMachine.find({ isActive:true })
      .populate('user', 'name email phone')
      .populate('machine', 'name price dailyEarning')
      .sort({ purchasedAt:-1 })
      .limit(500);
    res.json(owners);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.delete('/api/admin/machines/:id', protect, adminOnly, async (req, res) => {
  try {
    const m = await MiningMachine.findByIdAndDelete(req.params.id);
    if (!m) return res.status(404).json({ error:'Not found' });
    await logAdminAction(req, 'DELETE_MACHINE', m.name, `Deleted machine ${m.name}`);
    res.json({ message:'Machine deleted' });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// GET mining stats for admin (total purchases, total mining earned)
app.get('/api/admin/mining-stats', protect, adminOnly, async (req, res) => {
  try {
    const [totalOwned, totalMiningEarned, topMiners] = await Promise.all([
      UserMachine.countDocuments({ isActive:true }),
      UserMachine.aggregate([{ $group:{ _id:null, total:{ $sum:'$totalEarned' } } }]),
      UserMachine.aggregate([
        { $group:{ _id:'$user', earned:{ $sum:'$totalEarned' }, machines:{ $sum:1 } } },
        { $sort:{ earned:-1 } }, { $limit:5 },
        { $lookup:{ from:'users', localField:'_id', foreignField:'_id', as:'u' } },
        { $unwind:'$u' },
        { $project:{ name:'$u.name', email:'$u.email', earned:1, machines:1 } },
      ]),
    ]);
    res.json({ totalOwned, totalMiningEarned: totalMiningEarned[0]?.total || 0, topMiners });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// ═══════════════════════════════════════════════════════════
//  HIGH MINING MACHINE ROUTES
// ═══════════════════════════════════════════════════════════

// GET all high machines (user — only active, show open/countdown status)
app.get('/api/mining/high-machines', protect, async (req, res) => {
  try {
    const machines = await HighMachine.find({ isActive:true }).sort({ createdAt:-1 });
    res.json(machines);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// GET user's owned high machines
app.get('/api/mining/my-high-machines', protect, async (req, res) => {
  try {
    const owned = await UserHighMachine.find({ user:req.user._id, isActive:true })
      .populate('machine');
    res.json(owned.map(um => ({
      _id: um._id,
      claimed: um.claimed,
      claimedAt: um.claimedAt,
      purchasedAt: um.purchasedAt,
      machine: um.machine,
    })));
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// POST buy a high machine (STK push)
app.post('/api/mining/high-buy/:machineId', protect, depositLimiter, async (req, res) => {
  try {
    // SECURITY: Block duplicate pending STK
    const pendingTx = await Transaction.findOne({ user:req.user._id, status:'pending', method:'mpesa' });
    if (pendingTx) {
      const ageMinutes = (Date.now() - new Date(pendingTx.createdAt)) / 60000;
      if (ageMinutes < 5) return res.status(429).json({ error:'You have a pending payment. Please complete it first.' });
      pendingTx.status = 'failed'; await pendingTx.save();
    }
    const machine = await HighMachine.findById(req.params.machineId);
    if (!machine || !machine.isActive) return res.status(404).json({ error:'Machine not found' });
    if (!machine.isOpen) return res.status(400).json({ error:'This machine is currently closed. Wait for admin to open it.' });
    const now = new Date();
    if (machine.endTime && now > machine.endTime) return res.status(400).json({ error:'Countdown ended. Machine is now closed.' });
    if (machine.soldCount >= machine.totalSlots) return res.status(400).json({ error:'All slots are sold out.' });

    // Check not already purchased
    const alreadyOwned = await UserHighMachine.findOne({ user:req.user._id, machine:machine._id, isActive:true });
    if (alreadyOwned) return res.status(400).json({ error:'You already own this machine.' });

    const user = await User.findById(req.user._id);
    const tel = (req.body.phone || user.phone || '').replace(/\s/g,'').replace(/^0/,'254').replace(/^\+/,'');
    const result = await stkPush(tel, machine.price, 'ImpactVest', `${machine.name} High Miner`);
    if (result.ResponseCode !== '0') return res.status(400).json({ error: result.ResponseDescription || 'STK Push failed' });

    await Transaction.create({
      user: user._id, email: user.email, type:'deposit', amount: machine.price,
      label: `High Machine Purchase: ${machine._id}`,
      status:'pending', method:'mpesa',
      mpesaRef: result.CheckoutRequestID,
      checkoutRequestId: result.CheckoutRequestID,
    });
    res.json({ message:'📱 Check your phone for M-Pesa PIN prompt!', checkoutRequestId: result.CheckoutRequestID });
  } catch(e) { console.error(e); res.status(500).json({ error:'Server error' }); }
});

// POST claim earnings from high machine (only after countdown)
app.post('/api/mining/high-mine/:userMachineId', protect, mineLimiter, async (req, res) => {
  try {
    const um = await UserHighMachine.findOne({ _id:req.params.userMachineId, user:req.user._id, isActive:true })
      .populate('machine');
    if (!um) return res.status(404).json({ error:'Machine not found in your account' });
    if (um.claimed) return res.status(400).json({ error:'Earnings already claimed.' });
    const now = new Date();
    if (!um.machine.endTime) return res.status(400).json({ error:'Machine has no end time set. Contact support.' });
    if (now < new Date(um.machine.endTime))
      return res.status(400).json({ error:'Countdown not finished yet. Please wait.' });

    // SECURITY: Earning from DB only — verify machine record
    const machine = await HighMachine.findById(um.machine._id);
    if (!machine) return res.status(404).json({ error:'Machine not found' });
    const earned = machine.totalEarning;
    if (!earned || earned <= 0) return res.status(400).json({ error:'Invalid earning value' });

    // SECURITY: Atomic claim — only one claim ever succeeds
    const claimed = await UserHighMachine.findOneAndUpdate(
      { _id: um._id, user: req.user._id, claimed: false },
      { $set: { claimed: true, claimedAt: now } },
      { new: true }
    );
    if (!claimed) return res.status(400).json({ error:'Already claimed or unauthorized.' });

    // Credit balance atomically
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { $inc: { balance: earned, totalEarned: earned } },
      { new: true }
    );

    await Transaction.create({ user:user._id, email:user.email, type:'earning', amount:earned, label:`⚡ High Mining Reward — ${machine.name}`, status:'completed', method:'system' });
    console.log(`⚡ HIGH-MINE | user:${user._id} | +${earned} | machine:${machine._id} | balance:${user.balance}`);
    res.json({ message:`💰 +KSH ${earned.toLocaleString()} claimed from ${machine.name}!`, earned, newBalance: user.balance });
  } catch(e) { console.error(e); res.status(500).json({ error:'Server error' }); }
});


// Poll status of high machine purchase
app.get('/api/mining/high-buy-status/:checkoutRequestId', protect, async (req, res) => {
  try {
    const tx = await Transaction.findOne({ $or:[{mpesaRef:req.params.checkoutRequestId},{checkoutRequestId:req.params.checkoutRequestId}], user: req.user._id });
    if (!tx) return res.json({ status: 'pending' });
    if (tx.status === 'completed') {
      const owned = await UserHighMachine.findOne({ user: req.user._id, isActive: true })
        .populate('machine').sort({ purchasedAt: -1 });
      return res.json({ status: 'completed', owned: !!owned });
    }
    if (tx.status === 'failed') return res.json({ status: 'failed' });
    res.json({ status: 'pending' });
  } catch(e) { res.status(500).json({ error: 'Server error' }); }
});

// ── ADMIN HIGH MACHINE MANAGEMENT ──
app.get('/api/admin/high-machines', protect, adminOnly, async (req, res) => {
  try {
    const machines = await HighMachine.find().sort({ createdAt:-1 });
    res.json(machines);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.post('/api/admin/high-machines', protect, adminOnly, async (req, res) => {
  try {
    let { name, description, imageUrl, price, totalEarning, durationHours, totalSlots } = req.body;
    if (!name || !price || !totalEarning || !durationHours) return res.status(400).json({ error:'name, price, totalEarning, durationHours required' });
    name = escapeHtml(name); description = escapeHtml(description||'');
    const m = await HighMachine.create({ name, description, imageUrl, price, totalEarning, durationHours, totalSlots:totalSlots||100 });
    await logAdminAction(req, 'ADD_HIGH_MACHINE', name, `Added high machine ${name}`);
    res.json(m);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.put('/api/admin/high-machines/:id', protect, adminOnly, async (req, res) => {
  try {
    const m = await HighMachine.findByIdAndUpdate(req.params.id, req.body, { new:true });
    if (!m) return res.status(404).json({ error:'Not found' });
    await logAdminAction(req, 'EDIT_HIGH_MACHINE', m.name, `Edited high machine ${m.name}`);
    res.json(m);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Admin open machine (start countdown)
app.post('/api/admin/high-machines/:id/open', protect, adminOnly, async (req, res) => {
  try {
    const m = await HighMachine.findById(req.params.id);
    if (!m) return res.status(404).json({ error:'Not found' });
    const now = new Date();
    m.startTime = now;
    m.endTime = new Date(now.getTime() + m.durationHours * 3600 * 1000);
    m.isOpen = true;
    m.soldCount = 0;
    await m.save();
    await logAdminAction(req, 'OPEN_HIGH_MACHINE', m.name, `Opened high machine ${m.name}, ends ${m.endTime}`);
    res.json(m);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Admin close/reset machine
app.post('/api/admin/high-machines/:id/close', protect, adminOnly, async (req, res) => {
  try {
    const m = await HighMachine.findById(req.params.id);
    if (!m) return res.status(404).json({ error:'Not found' });
    m.isOpen = false;
    m.startTime = null;
    m.endTime = null;
    await m.save();
    await logAdminAction(req, 'CLOSE_HIGH_MACHINE', m.name, `Closed/reset high machine ${m.name}`);
    res.json(m);
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.delete('/api/admin/high-machines/:id', protect, adminOnly, async (req, res) => {
  try {
    const m = await HighMachine.findByIdAndDelete(req.params.id);
    if (!m) return res.status(404).json({ error:'Not found' });
    await logAdminAction(req, 'DELETE_HIGH_MACHINE', m.name, `Deleted high machine ${m.name}`);
    res.json({ message:'Deleted' });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Handle high machine purchase callback (similar to regular machine)

// ═══ SOCIAL PROOF MANAGER ═══════════════════════════════════
app.get('/api/admin/social-proof', protect, adminOnly, async (req, res) => {
  try {
    const docs = await SocialProof.find();
    const data = {};
    docs.forEach(d => data[d.key] = d.value);
    // Return with defaults if not set
    res.json({
      fakeEarners: data.fakeEarners || DEFAULT_EARNERS,
      fakeReferrers: data.fakeReferrers || DEFAULT_REFERRERS,
      extraInvestors: data.extraInvestors || 2847,
      extraPaidOut: data.extraPaidOut || 4850000,
      extraDeposited: data.extraDeposited || 12400000,
      apkExtraDownloads: data.apkExtraDownloads || 20000,
      fakePayouts: data.fakePayouts || [
        { name:'James M...', amount:45000 },
        { name:'Grace W...', amount:28500 },
        { name:'Peter K...', amount:15200 },
        { name:'Faith N...', amount:8900 },
        { name:'David O...', amount:12400 },
      ]
    });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

app.post('/api/admin/social-proof', protect, adminOnly, async (req, res) => {
  try {
    const { key, value } = req.body;
    if (!key || value === undefined) return res.status(400).json({ error:'Key and value required' });
    await SocialProof.findOneAndUpdate({ key }, { value }, { upsert:true });
    await logAdminAction(req, 'EDIT_SOCIAL_PROOF', key, 'Updated social proof data');
    res.json({ message:'Social proof updated' });
  } catch(e) { res.status(500).json({ error:'Server error' }); }
});

// Health
app.get('/api/health', (req, res) => res.json({ 
  status:'ok', 
  time:new Date(),
  jwt: process.env.JWT_SECRET ? 'set' : 'MISSING',
  mongo: process.env.MONGO_URI ? 'set' : 'MISSING',
  email_user: process.env.EMAIL_USER || 'NOT SET',
  brevo_api_key: process.env.BREVO_API_KEY ? 'set' : 'NOT SET — add BREVO_API_KEY in Render env',
  node: process.version,
  mpesa_env: process.env.MPESA_ENV || 'NOT SET',
  mpesa_base: getMpesaBase(),
  mpesa_shortcode: process.env.MPESA_SHORTCODE || 'MISSING',
  mpesa_consumer_key: process.env.MPESA_CONSUMER_KEY ? 'set' : 'MISSING',
  mpesa_consumer_secret: process.env.MPESA_CONSUMER_SECRET ? 'set' : 'MISSING',
  mpesa_passkey: process.env.MPESA_PASSKEY ? 'set' : 'MISSING',
  mpesa_callback: process.env.MPESA_CALLBACK_URL ? '✅ set' : 'MISSING',
}));

// ── TEST EMAIL ENDPOINT — use this to verify Gmail config works ──
// POST /api/auth/test-email  { "to": "youremail@gmail.com", "secret": "your-admin-secret" }
app.post('/api/auth/test-email', async (req, res) => {
  try {
    const { to, secret } = req.body;
    // Basic protection — require the same secret key used for admin seed
    if (!secret || secret !== process.env.ADMIN_SECRET_KEY)
      return res.status(403).json({ error: 'Invalid secret. Pass your ADMIN_SECRET_KEY.' });
    if (!to) return res.status(400).json({ error: 'Provide a "to" email address' });
    if (!process.env.BREVO_API_KEY)
      return res.status(500).json({ error: 'BREVO_API_KEY not set in Render environment vars' });
    if (!process.env.EMAIL_USER)
      return res.status(500).json({ error: 'EMAIL_USER not set — add your verified sender email' });

    const html = `
      <div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;background:#0d0f14;color:#e4eaf5;padding:32px;border-radius:16px">
        <h2 style="color:#c9a84c">✅ ImpactVest Email Test</h2>
        <p style="color:#6b7e99">If you received this, Gmail SMTP is working correctly on Render.</p>
        <p style="color:#4a6080;font-size:12px">Sent via: <strong>${process.env.EMAIL_USER}</strong></p>
        <p style="color:#4a6080;font-size:12px">Time: ${new Date().toISOString()}</p>
      </div>`;
    await sendEmail(to, '✅ ImpactVest Email Test — Working!', html);
    res.json({ success: true, message: `Test email sent to ${to}. Check inbox and spam.`, from: process.env.EMAIL_USER });
  } catch(e) {
    res.status(500).json({ success: false, error: e.message, hint: 'Check BREVO_API_KEY is correct and EMAIL_USER is a verified sender in Brevo dashboard.' });
  }
});

// M-Pesa credential tester — visit /api/mpesa/test-token to verify your creds work
app.get("/api/mpesa/test-token", async (req, res) => {
  try {
    const base = getMpesaBase();
    const token = await getMpesaToken();
    res.json({
      success: true,
      env: process.env.MPESA_ENV || 'NOT SET (defaulting to sandbox)',
      base_url: base,
      shortcode: process.env.MPESA_SHORTCODE,
      callback_url: process.env.MPESA_CALLBACK_URL,
      token_preview: token ? token.slice(0,10)+"..." : 'null',
      message: 'Credentials are valid — token fetched successfully'
    });
  } catch(e) {
    const errData = e.response?.data;
    res.status(400).json({
      success: false,
      env: process.env.MPESA_ENV || 'NOT SET (defaulting to sandbox)',
      base_url: getMpesaBase(),
      error: errData?.errorMessage || e.message,
      raw: errData,
      hint: process.env.MPESA_ENV !== 'production'
        ? 'MPESA_ENV is not set to production — using sandbox URL with live credentials will always fail!'
        : 'Check your MPESA_CONSUMER_KEY and MPESA_CONSUMER_SECRET are correct and your Daraja app is approved.'
    });
  }
});

// ═══════════════════════════════════════════════════════════
//  STATIC FILES — MUST BE LAST
// ═══════════════════════════════════════════════════════════
const publicPath = path.join(__dirname, 'public');
if (fs.existsSync(publicPath)) app.use(express.static(publicPath));

const ADMIN_PATH = process.env.ADMIN_PATH || '/manage-x7k9p';

// SECURITY: Admin panel — secret URL from env, brute-force protected
const adminPanelAttempts = new Map();
app.get(ADMIN_PATH, (req, res) => {
  const f = path.join(__dirname, 'public', 'admin.html');
  fs.existsSync(f) ? res.sendFile(f) : res.status(404).send('Not found');
});
// Block ALL other /manage* /admin* paths — return 404 NOT 403 (no hints)
app.get(['/admin.html','/admin','/admin/*','/manage','/panel','/dashboard','/control','/cp','/backend'], (req, res) => res.status(404).send('Not found'));
// Track wrong URL attempts (brute force detection)
app.use((req, res, next) => {
  const suspicious = ['/manage','/admin','/panel','/dashboard','/control','/cp','/backend','/secret'];
  const isSuspicious = suspicious.some(p => req.path.toLowerCase().startsWith(p)) && req.path !== ADMIN_PATH;
  if (isSuspicious) {
    const ip = (req.headers['x-forwarded-for']||req.socket.remoteAddress||'').split(',')[0].trim();
    const attempts = (adminPanelAttempts.get(ip)||0) + 1;
    adminPanelAttempts.set(ip, attempts);
    console.warn(`🚨 Admin panel brute-force attempt #${attempts} from ${ip}: ${req.path}`);
    if (attempts >= 10) {
      // After 10 wrong attempts, block IP for 1 hour
      console.warn(`🔒 IP ${ip} blocked for admin brute-force`);
      return res.status(404).send('Not found');
    }
  }
  next();
});

app.get('*', (req, res) => {
  const f = path.join(__dirname, 'public', 'index.html');
  if (!fs.existsSync(f)) return res.json({ message:'ImpactVest API running', status:'ok' });
  // Block hacking tools and scrapers from reading HTML source
  const ua = (req.headers['user-agent'] || '').toLowerCase();
  const isTool = ['curl','wget','python','httpie','go-http','postman','insomnia','burpsuite','zaproxy','nikto','sqlmap','nmap','scrapy','requests','axios','java/'].some(t => ua.includes(t));
  if (isTool) return res.status(200).send('<!DOCTYPE html><html><head><title>ImpactVest</title></head><body></body></html>');
  res.sendFile(f);
});

app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error:'Internal server error' }); });

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 ImpactVest API running on port ${PORT}`));
